#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.dirname(File.expand_path(__FILE__))))}/ruby/ytilib/"
require "ytilib.rb"
require "ftools"

require "html.rb"

report "dmmpmm_list_html.rb started, usage <result_directory> <data_directory>"
start __FILE__

exit(2) if ARGV.size < 2

$maindir = "list-#{ARGV[1]}"
$mainfile = "list-#{ARGV[1]}.html"
$datadir = ARGV[1]
$home = "../#{$mainfile}"

def colorchooser(i)
#  return " class='green'" if $factors_data[i][:sequence_count] > 8
  return ""
end

def colchomo(f,l)
  return " class='green'" if $f[:motif_length] == l
  return ""
end

$factors_data = []
Dir.chdir(ARGV[0]) {
  
  Dir["#{$datadir}/*"].each { |factor_dir|
  	next unless File.directory?(factor_dir)
  	report "scanning #{factor_dir}"
    factor_id = File.basename(factor_dir)
    factor_data = {}
    parex = Rereader.new(factor_dir)
    factor_data[:factor_id] = factor_id
    factor_data[:motif_length] = parex.get("bifooxi","MOTIF_LENGTH")[:value]
    factor_data[:flank_length] = parex.get("flancalc","FLANK_LENGTH")[:value]
    factor_data[:sequence_count] = parex.get("bifoosig","SEQUENCE_COUNT")[:value]
    factor_data[:ready] = "#{factor_id}_ready.xml"
    factor_data[:map] = "#{factor_id}_map.xml"
    factor_data[:sites] = "#{factor_id}_sites.xml"
    factor_data[:namet] = "../#{$datadir}/#{factor_id}/#{factor_id}_motif"
    
    $factors_data << factor_data
  }
  
  $factors_data.sort! { |a,b| a[:factor_id] <=> b[:factor_id]  }
  
  Dir.mkdir($maindir) unless File.exist?($maindir)
  Dir.chdir($maindir) {
    $factors_data.each { |f|
      
      $f = f
      $fid, wc = f[:factor_id], f[:sequence_count]
      
      report "processing #{$fid}"
      
      report "mapping sites in footprints using 'ready' motif"
      mapres = `ruby #{Ytilib::PATH_RUBY}pmenha/pmapp.rb ../#{$datadir}/#{$fid}/#{f[:ready]} ../#{$datadir}/#{$fid}/#{$fid}_footprints.xml dmel40 #{f[:flank_length]} ../#{$datadir}/#{$fid}/#{$fid}_map.xml`
      
      report "processing genome-mapping of sites within footprints using 'ready' motif"
      `ruby #{Ytilib::PATH_RUBY}pmenha/pmsit.rb ../#{$datadir}/#{$fid}/#{f[:ready]} ../#{$datadir}/#{$fid}/#{$fid}_footprints.xml dmel40 #{f[:flank_length]} ../#{$datadir}/#{$fid}/#{$fid}_sites.xml`
      
      $f[:shift] = {}
      motiflist = (6..15).inject("") { |list, l| list += " ../#{$datadir}/#{$fid}/#{$fid}_motif_#{l}.xml"}
      shifts = `ruby ../../dmmpmm_shiftcalc.rb yes #{motiflist}`.split("\n").last.strip.split
      
      (6..15).each { |l|
        $f[:shift][l] = shifts[l-6].to_i * 30
        `ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo.rb #{f[:namet]}_#{l}.xml #{$fid}_#{l}.png #{wc} 30 60 discrete` unless File.exist?("#{$fid}_#{l}.png")
      }
      
      `ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo.rb ../#{$datadir}/#{$fid}/#{f[:ready]} #{$fid}_ready.xml.png #{wc} 30 60 discrete` unless File.exist?("#{$fid}_ready.xml.png")
      `ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo.rb ../#{$datadir}/#{$fid}/#{f[:ready]} ../#{$datadir}/#{$fid}/#{f[:ready]}.png #{wc}`
      
      r = html("../../dmmpmm_list_motif.rhtml", "DMMPMM Bigfoot motif #{$fid} sheet", "../../dmmpmm.css")
      File.open("#{$fid}.html", "w") { |f| f << r }
      
    }
  }
  
  r = html("../dmmpmm_list.rhtml", "DMMPMM Bigfoot motif list", "../dmmpmm.css")
  File.open($mainfile, "w") { |f| f << r }
}