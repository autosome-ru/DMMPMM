#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.dirname(File.expand_path(__FILE__))))}/ruby/ytilib/"

require "ytilib.rb"
require "ftools"

require "html.rb"

report "dmmpmm_compare_html.rb started, usage <result_directory/dmmpmm_compare_result>"
start __FILE__
exit if ARGV.size == 0

def colorchooser(row,i)
  row = row.split("\t")
  v = row[i]
  data = row.collect { |r| r.to_i }
  datacolumns = (3..100).select { |i1| (i1+1) % 2 == 0 && i1 < row.size } 
  data = datacolumns.collect { |d| data[d] }.compact
  return " class='green'" if datacolumns.include?(i) && v.to_i == data.max
  case i
  when 3..100
    return " class='yellow'" if i % 2 != 0 && v.to_i > 0
  else
    ""
  end
end

$compare = IO.read(ARGV[0]).split("\n")
$headline = $compare.shift.split("\t")
$base_dir = "#{File.dirname(ARGV[0])}/#{File.name_wo_ext(ARGV[0])}"

$home_dir = File.name_wo_ext(ARGV[0])

r = html("dmmpmm_compare.rhtml", "DMMPMM motif selectivity testing - AhoPro P-value calculator on the initial footprint set", "../dmmpmm.css")
$home = File.dirname(ARGV[0]) + '/' + File.name_wo_ext(ARGV[0]) + ".html"
File.open($home, "w") { |f| f << r }
$home = '../' + File.name_wo_ext(ARGV[0]) + ".html"

$sources = $headline[3..-1].collect{ |h| h.split[0] }.uniq
$sources.delete('Bigfoot')
$sources.insert(0, 'Bigfoot')

Dir.chdir($base_dir) {
  Dir["*"].each { |name|
    next unless File.directory?(name)
    $motif = name
    
    report "processing #{name}"
    
    $filtersor = $sources.select { |sor| File.exist?("#{$motif}/#{sor}_motif.xml") }
    motiflist = $filtersor.inject("") { |list, sor| list += " #{$motif}/#{sor}_motif.xml"}
    shifts = `ruby ../../dmmpmm_shiftcalc.rb false #{motiflist}`.split("\n").last.strip.split
    $shifts = {}
    $filtersor.each_with_index { |s,i| $shifts[s] = shifts[i].to_i*30 }
    
    # loading similarity comparison results
    $simcompres = IO.read("#{$motif}/#{$motif}_similarity.txt").split("\n")
    $simcompres_h = $simcompres.shift.split
    
    $simcompres = $simcompres.collect { |line| line.split[1..-1] }
    
    r = html("../../dmmpmm_compare_motif.rhtml", "DMMPMM motif #{name} selectivity testing - AhoPro P-value calculator on initial footprint set", "../../dmmpmm.css")
    File.open("#{name}.html", "w") { |f| f << r }
  }
}