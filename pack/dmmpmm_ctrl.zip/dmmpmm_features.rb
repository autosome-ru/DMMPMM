#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.dirname(File.expand_path(__FILE__))))}/ruby/ytilib/"
require "ytilib.rb"
require "ftools"

report "dmmpmm_features.rb started, usage <result_directory/method_directory> [<post_filtering>]"
start __FILE__
exit if ARGV.size == 0

dir = ARGV[0]
post_filter = ARGV[1]

Dir.chdir(dir) { 
  file = File.new("../features-" + File.basename(dir)+".txt", "w")
  file.puts("factor id\taverage score\tbest score\tworst score\tavg+sigma\tavg+2sigma\tavg+3sigma\tsequence count\tsequences w/o score > average+sigma\tsequences w/o scores > average+3sigma\tworst site in the set\tbest site in the set\tflank length\tsites appearing on <flank length>\tsites apperaring on 2bp flanks\t% w/o sites\t% sites in flanks\t% sites in 2bp flanks\t% weak sites\tthreshold\tweak words in the 'ready' motif")

  Dir["../BE_DMEL-footprint-Bigfoot/*"].sort.each { |dir_factor|
    dir_factor = File.basename(dir_factor)
    
    next unless File.directory?(dir_factor)
    Dir.chdir(dir_factor) {
      motif_file = "#{dir_factor.upcase}_motif.xml"
      next unless File.exist?(motif_file)
      rmotif_file = "#{dir_factor}_ready.xml"
      report "processing #{dir_factor}"
      
      bismark = Bismark.new(motif_file)
      motif_name = bismark.elements["//motif"].attributes["name"]
      pm = PM.from_bismark(bismark.elements["//PPM"], true)
      words = []
      bismark.elements.each("//word") { |e|
        words << e.get_text.to_s
      }
      
      File.copy("../../BE_DMEL-footprint-Bigfoot/#{dir_factor}/#{dir_factor}_footprints.xml", "#{dir_factor}_footprints.xml") unless File.exist?("#{dir_factor}_footprints.xml")
      
      words_count = Bismark.new("#{dir_factor}_footprints.xml").elements["//group"].attributes["size"].to_i
      if bismark.elements["//PCM"]
        words_count = PM.from_bismark(bismark.elements["//PCM"]).words_count
      end
      
      bismark = Bismark.new
      bismark.root.add_element("motif", {"id" => "#{motif_name.to_id}.MTF", "name" => "#{motif_name}"})
      pm.to_bismark(bismark.elements["//motif"])
      
      # Creating PWM-motif taking into account background probs for dmel40
      pm = pm.get_pwm(words_count, Randoom::DMEL40_PROBS2)
      
      pm.to_bismark(bismark.elements["//motif"])
      unless words.empty?
        bi_wl = bismark.elements["//motif"].add_element("word-list", {"size" => words.size})
        words.each { |w|
          bi_wl.add_element("word", {"score" => pm.score(w)}).add_text(w)
        }
      end
      
      File.open(rmotif_file, "w") { |f| f << bismark.getXML }
      
      # here we can change MC times (last parameter) to increase threshold estimation quality, default = 1048576 (4**10)
      flkscn3 = `ruby #{Ytilib::PATH_RUBY}pmenha/flkscn3.rb #{rmotif_file} #{dir_factor}_footprints.xml dmel40`
      
      flkscn3 = flkscn3.scan(/\w+=\S+/)
      flkscn3 = flkscn3.collect { |s| s.split(/[=,]/)[1] }
      average, best, worst, sigma1, sigma2, total_count, wosite_count, 
        sigma3, wostrict_count, worst_in_the_set, best_in_the_set, flank_length, appeared_sites, flank_length2, appeared_sites2 = flkscn3
      flank_length = appeared_sites = appeared_sites2 = "" unless flank_length
      
      pe_wosite = wosite_count.to_f / total_count.to_f * 100
      pe_siteinf = appeared_sites.to_f / total_count.to_f * 100
      pe_sitein2f = appeared_sites2.to_f / total_count.to_f * 100
      pe_weak = (wostrict_count.to_f - wosite_count.to_f) / total_count.to_f * 100

      threshold = threshold_idea = sigma3.to_f
      threshold = threshold.round_to(2)
      
      bad_sites = words.select { |w|
        pm.score(w) < threshold
      }.size
      
      motif_wt = Bismark.new(rmotif_file)
      motif_wt.elements["//PWM"].add_attribute("threshold", threshold.to_s)
      motif_wt.elements["//motif"].add_attribute("length", pm.size.to_s)
      File.open(rmotif_file, "w") { |f| f << motif_wt.getXML }
      
      checkerr("bad 'small try' flank length") { flank_length2 && flank_length2 != "2"}
      file.puts("#{dir_factor}\t#{average}\t#{best}\t#{worst}\t#{sigma1}\t#{sigma2}\t#{sigma3}\t#{total_count}\t#{wosite_count}\t#{wostrict_count}\t#{worst_in_the_set}\t#{best_in_the_set}\t#{flank_length}\t#{appeared_sites}\t#{appeared_sites2}\t#{pe_wosite}\t#{pe_siteinf}\t#{pe_sitein2f}\t#{pe_weak}\t#{threshold}\t#{bad_sites}") if average
      
      if post_filter
        flank_length = pm.size
        flanked_foots = "#{dir_factor}_footprints_#{flank_length}.xml"
        background = "#{Randoom::DMEL40_PROBS2['A']},#{Randoom::DMEL40_PROBS2['C']},#{Randoom::DMEL40_PROBS2['G']},#{Randoom::DMEL40_PROBS2['T']}"
        system("ruby #{Ytilib::PATH_RUBY}/by/by_segseq.rb #{dir_factor}_footprints.xml dmel40 #{flank_length} #{flanked_foots}")
        system("ruby #{Ytilib::PATH_RUBY}/pmenha/pmfin.rb #{motif_file} #{rmotif_file} #{flanked_foots} 1 #{background} #{sigma2}")
      end

    }
  }
}