#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.dirname(File.expand_path(__FILE__))))}/ruby/ytilib/"

require "ytilib.rb"

report "segexbsm.rb started, usage: <bismark_file> <source_id> <factor_name> <genome_release> [<verbose>]"
start __FILE__

bismark_f_n, source_id, factor_name, genome_release = ARGV
exit(2) if ARGV.size < 4
verbose = ARGV[4] != nil

my = Ytilib.new_mysql_conn("bismark")
query = "SELECT id, chromosome, location, length, type FROM segment where source_id = '#{source_id}' and factor_name = '#{factor_name}'"
report query
res = my.query(query)

checkerr("no data on #{factor_name} from #{source_id}") { res.num_rows == 0 }

bismark = Bismark.new

bismark.root.add_element("comment", {"name" => "bismark extraction parameters"}).add_text("source_id=#{source_id},factor_name=#{factor_name}")
b_g = bismark.root.add_element("group", {"name" => "bismark extracted sequences", "size" => res.num_rows})

res.each { |row|
  chromosome, location, length = row[1], row[2].to_i, row[3].to_i
  sequence = Seqripper.extract(genome_release, chromosome, location, length).upcase
  report "bismarking #{row[0]}" if verbose
  Segment.new(chromosome, location, length, nil, row[0], sequence).to_bismark(b_g)
}

Rekeeper.keepr("BISMARK_OUT", bismark_f_n, "segments extracted from bismark db using source_id=#{source_id}, factor_name=#{factor_name}")
File.open(bismark_f_n, "w") { |f| f << bismark.getXML }