#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.dirname(File.expand_path(__FILE__))))}/ruby/ytilib/"
require "ytilib.rb"
require "ftools"

report "dmmpmm_simkoef.rb started, usage <result_directory/method_directory>"
start __FILE__

exit(2) if ARGV.empty?
dir = ARGV[0]

Dir.chdir(dir) { 
  out = File.new("../similarity-" + File.basename(dir)+".txt", "w")
  report "loading factors"
  factors = Dir["*"].sort.select { |dir_factor| File.directory?(dir_factor) }
  factors_good = factors.select { |factor_id| File.exist?("#{factor_id}/#{factor_id}_ready.xml") }.sort
  checkerr("no 'ready' motifs found") { factors_good.size == 0 }
  report "loading PWMs"
  pwms = factors_good.collect { |factor_id| PM.from_bismark(Bismark.new("#{factor_id}/#{factor_id}_ready.xml").elements["//PWM"]) }
  treshs = factors_good.collect { |factor_id| 
    scores = []
    Bismark.new("#{factor_id}/#{factor_id}_ready.xml").elements.each("//word") { |we|
      scores << we.attribute("score").value.to_f
    }
    newthr = scores.average
    oldthr = Bismark.new("#{factor_id}/#{factor_id}_ready.xml").elements["//PWM"].attribute("threshold").value.to_f
    report "for #{factor_id} got ready threshold=#{oldthr}, average score=#{newthr}, using #{oldthr}"
    oldthr
  }
  
  out.puts factors_good.inject("") { |s, f_n| s << "\t#{f_n}" }
  
  blacklist = []
  result = {}
  pwms.each_with_index { |pwm1, i|
    report "processing #{factors_good[i]}"
    
    simkoefs = ""
    
    pwms.each_with_index { |pwm2, j|
      report "processing #{factors_good[i]} vs #{factors_good[j]} (#{j} of #{pwms.size})"
      if result[[i,j].sort]
        simkoefs << "\t#{result[[i,j].sort]}"
      elsif blacklist.include?(j)
        result[[i,j].sort] = "*"
        simkoefs << "\t*"
      else
        curmaxlen = pwm1.size + pwm2.size - 1
        p_a = Extlz.p_value(pwm1, treshs[i], curmaxlen, true, Randoom::DMEL40_PROBS2)
        unless p_a
          blacklist << i
          simkoefs = "\t*"*pwms.size
          break
        end
        p_b = Extlz.p_value(pwm2, treshs[j], curmaxlen, true, Randoom::DMEL40_PROBS2)
        unless p_b
          blacklist << j
          simkoefs << "\t*"
          next
        end
        
        p_ab = Extlz.p_value([pwm1, pwm2], [treshs[i],treshs[j]], curmaxlen, true, Randoom::DMEL40_PROBS2)
        if p_ab
          simkoef = p_ab / Math.sqrt(p_a * p_b)
          result[[i,j].sort] = simkoef
          simkoefs << "\t#{simkoef}"
        else
          result[[i,j].sort] = "*"
          simkoefs << "\t*"
        end
      end
    }
    
    out.puts "#{factors_good[i]}#{simkoefs}"
  }
  Dir["*.prob"].each { |fn| File.delete(fn) }
  Dir["*.pat"].each { |fn| File.delete(fn) }
}
