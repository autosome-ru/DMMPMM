#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.dirname(File.expand_path(__FILE__))))}/ruby/ytilib/"

require "ytilib.rb"
require "ftools"

program_path = File.dirname(File.expand_path(__FILE__))

report "dmmpmm.rb started, usage [<result_directory>]"
start __FILE__

$factor_names = {}
def process(cudnam, so_me_id)
  report "processing #{so_me_id} source+method"
  
  if !File.exist?(cudnam)
    Dir.mkdir(cudnam)
  end
  
  Dir.chdir(cudnam) {
    
    $factor_names[so_me_id].each { |factor_name|
      
      factor_id = factor_name.to_id
      
      report "<#{so_me_id}> processing motif #{factor_name}, id=#{factor_id}"
      
      # 1. Creating original set of footprints
      set_f_n = factor_id + "_footprints.xml"
      
      #a simple stub for multicore processing
      if File.exist?(factor_id)
        report "no processing required on #{factor_id}"
        next
      end
      
      Dir.mkdir(factor_id) if !File.exist?(factor_id)
      Dir.chdir(factor_id) { yield(factor_name, factor_id) }
    }
  }
end

wd = ARGV[0] ? ARGV[0] : "DMMPMM_" + Ytilib.time.to_id

Dir.mkdir(wd) unless ARGV[0]
Dir.chdir(wd) { 

  Rekeeper.keepp("GENOME_RELEASE", "dmel40", "genome release used for data processing")

  my = Ytilib.new_mysql_conn("bismark")
  
  # Processing all possible factor names for BE_DMEL
  foots_counts = {}
  my = Ytilib.new_mysql_conn("bismark")
  query = "SELECT count(*) as foots_count, factor_name FROM segment where source_id = 'BE_DMEL' and factor_name is not null group by factor_name"
  res = my.query(query)
  res.each { |row|
    foots_count, factor_name = row[0].to_i, row[1]
    foots_counts[factor_name] = foots_count
  }
  
  $factor_names["BE_FO_BF"] = foots_counts.keys.select { |factor| foots_counts[factor] >= 8 }.sort { |b,a| foots_counts[a] <=> foots_counts[b] }
  $factor_names["BE_FO_S0"] = $factor_names["BE_FO_BF"]
  
  # Bergman footprint data | Bigfoot 
  bigfoot_cudnam = cudnam = "BE_DMEL-footprint-Bigfoot_ctrl"
  Rekeeper.keepr("BE_FO_BF", cudnam, "Bergman footprinting data processed using Bigfoot engine with length fixed from Pollard data")
  
  process(cudnam, "BE_FO_BF") { |factor_name, factor_id|
    
    system("ruby #{program_path}/segexbsm.rb #{factor_id + '_footprints.xml'} BE_DMEL #{factor_name.cmd_line} dmel40")
    foots_bismark = "#{factor_id}_footprints.xml"
    bigfoot_motif = "#{factor_id}_motif.xml"
    
    motif_length = Bismark.new("../../BE_DMEL-footprint-Pollard/#{factor_id}/#{factor_id}_motif.xml").elements["//PPM"].attributes["length"].to_i
    system("ruby #{Ytilib::PATH_RUBY}pmenha/flancalc.rb #{foots_bismark} 6 #{motif_length} 1")
    
    File.copy("../../BE_DMEL-footprint-Bigfoot/#{factor_id}/#{factor_id}_motif_#{motif_length}.xml", "#{bigfoot_motif}")
    system("ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo.rb #{bigfoot_motif} #{bigfoot_motif}.png #{foots_counts[factor_name]}") unless File.exist?("#{bigfoot_motif}.png")    
    
  }
  
  # Bergman footprinted data | SeSiMCMC
  cudnam = "BE_DMEL-footprint-SeSiMCMC_ctrl"
  Rekeeper.keepr("BE_FO_S0", cudnam, "Bergman footprinting data processed using SeSiMCMC sampler (zero motif absence prior) with length fixed from Pollard data")
  
  process(cudnam, "BE_FO_S0") { |factor_name, factor_id|
    set_f_n = factor_id + "_footprints.xml"
    
    # 1. Extracting segments from bismark db
    system("ruby #{program_path}/segexbsm.rb #{set_f_n} be_dmel #{factor_name.cmd_line} dmel40")
    
    # 2. Saving fasta file without flanking regions
    system("ruby #{Ytilib::PATH_RUBY}by/by_seg2mfa.rb #{set_f_n} #{factor_id}_footprints.fasta dmel40")
    
    # 3. Building a motif by SeSiMCMC using Bigfoot_ctrl sample as basis
    parex = Rereader.new("../../#{bigfoot_cudnam}/#{factor_id}")
    
    motif_length = Bismark.new("../../BE_DMEL-footprint-Pollard/#{factor_id}/#{factor_id}_motif.xml").elements["//PPM"].attributes["length"].to_i
    flank_length = parex.get("flancalc", "FLANK_LENGTH")
    
    # SeSiMCMC wins using the longest motif all over the time?
    flank_length = flank_length[:value].to_i
    
    system("ruby #{Ytilib::PATH_RUBY}use/use_sesi.rb #{set_f_n} dmel40 #{factor_id}_motif.xml #{factor_name.cmd_line} #{motif_length} #{flank_length} 0.0 #{motif_length} 100 all yes")
  
  }
  
  Rekeeper.flush
}
