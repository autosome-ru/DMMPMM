#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.dirname(File.expand_path(__FILE__))))}/ruby/ytilib/"
require "ytilib.rb"

require "ftools"

report "dmmpmm_noyes.rb started, usage <result_name> [<result_directory>]"
start __FILE__

exit(2) if ARGV.size < 1
wd = ARGV[1] ? ARGV[1] : "DMMPMM_" + Ytilib.time.to_id
result_name = ARGV[0]

Dir.mkdir(wd) unless ARGV[1]
Dir.chdir(wd) {
  Dir.mkdir(result_name) if !File.exist?(result_name)
  Dir.chdir(result_name) {
    Dir["../../indata/noyes/*.mfa"].each { |mfaf|
      factor_name = File.name_wo_ext(mfaf)
      factor_id = factor_name.to_id
      
      # simple stub for parallel running
      next if File.exist?(factor_id)
      
      seqs = Ytilib.read_mfa2array(mfaf)
      sequence_count = seqs.size
      max_ml = seqs.collect { |s| s.size }.max + 1
      max_ml = 15 if max_ml > 15
      
      Dir.mkdir(factor_id) unless File.exist?(factor_id)
      Dir.chdir(factor_id) {
      
        system("ruby #{Ytilib::PATH_RUBY}by/by_mfa2seg.rb ../#{mfaf} #{factor_id}_noyes.xml yes") unless File.exist?("#{factor_id}_noyes.xml")
        
        #(6..max_ml).each { |ml|
        #  system("ruby #{Ytilib::PATH_RUBY}pmenha/bigfoot.rb #{factor_id}_motif_#{ml}.xml #{factor_id}_noyes.xml #{factor_name.cmd_line} none #{ml} 0 yes yes yes")
        #}
        
        parex = Rereader.new
        system("ruby #{Ytilib::PATH_RUBY}pmenha/bifoosig.rb #{factor_id}_motif.xml #{factor_id}_noyes.xml #{factor_name.cmd_line} none 1 disabled 6 #{max_ml} yes") # unless parex.get("bifoosig", "MOTIF_FOUND")
        
        system("ruby #{Ytilib::PATH_RUBY}pmenha/bifoocut.rb #{sequence_count} #{factor_id}_motif_ 6 #{max_ml} xi2 0.05")
        parex = Rereader.new
        motif_length = parex.get("bifoocut", "MOTIF_LENGTH")[:value]
        
        File.copy("#{factor_id}_motif_#{motif_length}.xml", "#{factor_id}_motif.xml")
        system("ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo1.rb #{factor_id}_motif.xml #{factor_id}_motif.xml.png #{sequence_count}")
      }
    }
  }
}