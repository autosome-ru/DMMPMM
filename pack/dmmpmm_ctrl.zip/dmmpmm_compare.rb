#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.dirname(File.expand_path(__FILE__))))}/ruby/ytilib/"
require "ytilib.rb"
require "ftools"

def load_p_values(result_name)
  return nil unless File.exist?("#{result_name}.p_value")
  p_values = {}
  p_values.default = 1.0
  IO.read("#{result_name}.p_value").each_line { |line|
    line = line.split
    p_values[line[0].to_i] = [line[1].to_f, p_values[line[0].to_i]].min
  }
  return p_values
end

report "dmmpmm_compare.rb started, usage <result_directory>"
start __FILE__

exit(2) if ARGV.empty?

result_dir = ARGV[0]
sources = ["BE_DMEL-footprint-Bigfoot_ctrl",
           "BE_DMEL-footprint-SeSiMCMC_ctrl",
           "BE_DMEL-footprint-Pollard"]

short_sources = {"BE_DMEL-footprint-Bigfoot_ctrl" => "Bigfoot_ctrl", 
                 "BE_DMEL-footprint-SeSiMCMC_ctrl" => "SeSiMCMC_ctrl", 
                 "BE_DMEL-footprint-Pollard" => "Pollard"}

sources_order  = ["Bigfoot_ctrl", "SeSiMCMC_ctrl", "Pollard"]

Dir.chdir(result_dir) {
  
  result = {}
  
  Dir.mkdir("comparison-DMMPMM_ctrl") unless File.exist?("comparison-DMMPMM")
  Dir.chdir("comparison-DMMPMM_ctrl") {
    Dir["../BE_DMEL-footprint-Bigfoot/*"].sort.each { |name|
      next unless File.directory?(name)
      
      factor_id = File.basename(name).upcase
      
      report "processing #{factor_id}"
      
      parex = Rereader.new("../BE_DMEL-footprint-Bigfoot/#{factor_id}")
      
      reference_motif = PM.from_bismark(Bismark.new("../BE_DMEL-footprint-Bigfoot_ctrl/#{factor_id}/#{factor_id}_motif.xml").elements["//PPM"], true)
      
      #We are taking the best word from reference motif
      reference_word = reference_motif.best_word
      
      # simple stub for parallel processing
      # next if File.exist?(factor_id)
      Dir.mkdir(factor_id) unless File.exist?(factor_id)
      
      File.copy("../BE_DMEL-footprint-Bigfoot/#{factor_id}/#{factor_id}_footprints.xml", "#{factor_id}/#{factor_id}_footprints.xml") unless File.exist?("#{factor_id}/#{factor_id}_footprints.xml")
      
      segs_size = XPath.match(Bismark.new("#{factor_id}/#{factor_id}_footprints.xml"), path="//segment").size
      
      p_value_lb, p_value_rb = (segs_size/100.0 * 10).ceil, (segs_size/100.0 * 90).floor
      p_value_tb = p_value_rb - p_value_lb + 1
      
      Dir.chdir(factor_id) {
        
        motif_list = ""
        motif_lengths = []
        
        sources.each { |source|
          
          if File.exist?("../../#{source}/#{factor_id}/#{factor_id}_motif.xml")
            
            report "processing #{factor_id}(#{source})"
            ready_motif_path = "../../#{source}/#{factor_id}/#{factor_id}_ready.xml"
            pcm_bismark = Bismark.new("../../#{source}/#{factor_id}/#{factor_id}_motif.xml")
            motif_lengths << pcm_bismark.elements["//PPM"].attributes["length"].to_i
            
            current_motif = PM.from_bismark(Bismark.new(ready_motif_path).elements["//PPM"], true)
            
            pcm_present = pcm_bismark.elements["//PCM"] || short_sources[source] == "Bigfoot" || short_sources[source] == "Noyes" || short_sources[source] == "Noyeshd" || short_sources[source] == "Bigfoot_ctrl"
            
            if short_sources[source] == "Bigfoot" || short_sources[source] == "Bigfoot_ctrl"
              words_count = segs_size
            elsif short_sources[source] == "Noyes"
              words_count = XPath.match(Bismark.new("../../#{source}/#{factor_id}/#{factor_id}_noyes.xml"), path="//segment").size
            elsif short_sources[source] == "Noyes_hd"
              words_count = Ytilib.read_mfa2array("../../#{source}/#{factor_id}/#{factor_id}_motif.mfa").size
            else
              words_count = pcm_present ? PM.from_bismark(pcm_bismark.elements["//PCM"]).words_count : :default
            end
            
            current_motif = current_motif.get_pwm(words_count == :default ? segs_size : words_count, Randoom::DMEL40_PROBS2)
            
            reference_sequence = "N"*(current_motif.size-1) + reference_word + "N"*(current_motif.size-1)
            
            if current_motif.best_hit(reference_sequence) > current_motif.best_hit(reference_sequence, false)
              report "changing motif orientation"
              `ruby #{Ytilib::PATH_RUBY}by/by_motif2revcomp.rb #{ready_motif_path} #{ready_motif_path}`
            end
            if pcm_present
              `ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo1.rb #{ready_motif_path} #{ready_motif_path}.png #{words_count}`
            else
              `ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo1.rb #{ready_motif_path} #{ready_motif_path}.png default default default weblogo`
            end
            
            File.copy("../../#{source}/#{factor_id}/#{factor_id}_ready.xml", "#{short_sources[source]}_motif.xml")
            `ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo.rb #{short_sources[source]}_motif.xml #{short_sources[source]}_motif.xml.png #{words_count} 30 60 #{words_count == :default ? :weblogo : :discrete}`
            
            # adding motif to compare selectivity
            motif_list << " #{short_sources[source]}_motif.xml"
          end
        }
        
        background = "#{Randoom::DMEL40_PROBS2['A']},#{Randoom::DMEL40_PROBS2['C']},#{Randoom::DMEL40_PROBS2['G']},#{Randoom::DMEL40_PROBS2['T']}"
        report "running similarity comparison"
        system("ruby #{Ytilib::PATH_RUBY}pmenha/pmsim.rb #{factor_id}_similarity.txt #{background} #{motif_list}") unless File.exist?("#{factor_id}_similarity.txt")
        report "running selectivity comparison"
        # not using strict flanks - 'no'
        system("ruby #{Ytilib::PATH_RUBY}pmenha/pmcmp.rb #{factor_id}_comparison #{factor_id}_footprints.xml dmel40 #{motif_lengths.max} yes 100 #{background} PWM #{motif_list}") unless File.exist?("#{factor_id}_comparison.plot")
        
        p_values_list = {}
        sources.each { |source|
          p_values_current = load_p_values("#{short_sources[source]}_motif")
          p_values_list[short_sources[source]] = p_values_current if p_values_current
        }
        
        result_list = {}
        result_list.default = nil
        p_values_list.keys.each { |k| result_list[k] = 0 }
        
        (p_value_lb..p_value_rb).each { |count|
          app_pvs = p_values_list.keys.collect { |shso| [shso, p_values_list[shso][count]] }
          app_pvs.sort! { |a,b| a[1] <=> b[1] }
          best_pvs = app_pvs[0]
          checkerr("broken calculation, best motif has P-value = 1.0") { best_pvs[1] == 1.0 }
          
          app_pvs.select { |avs| avs[1] == app_pvs[0][1] }.each { |avs|
            result_list[avs[0]] += 1
          }
          
        }
        
        best = sources_order.select { |source| result_list[source] == result_list.values.max }[0]
        
        result_list.each_key { |shsc| 
          result_list[shsc] = { :score => result_list[shsc], :length => Bismark.new("#{shsc}_motif.xml").elements["//PPM"].attributes["length"]}
        }
        
        result_list["Best"] = best
        result_list["Total"] = p_value_rb - p_value_lb + 1
        
        result[factor_id] = result_list
        
      }
    }
  }
  
  newk = []
  File.open("comparison-DMMPMM_ctrl.txt", "w") { |f|
    f << "factor id\tbest motif\ttotal points in [10%, 90%]"
    short_sources.values.uniq.sort.each { |shsc| 
      f << "\t#{shsc} score\t#{shsc} length"
      newk << shsc
    }
    f.puts
    result.keys.sort.each { |factor|
      f << "#{factor}\t#{result[factor]['Best']}\t#{result[factor]['Total']}"
      newk.each { |nk|
        f << (result[factor][nk] ? "\t#{result[factor][nk][:score]}\t#{result[factor][nk][:length]}" : "\t\t")
      }
      f.puts
    }
  }
}