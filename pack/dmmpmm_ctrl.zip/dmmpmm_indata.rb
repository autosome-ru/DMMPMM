#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.dirname(File.expand_path(__FILE__))))}/ruby/ytilib/"
require "ytilib.rb"
require "ftools"

def process_input(s)
  motifs, motif = {}, {}
  matrix, words, motif_name = nil, nil, nil

  s.each_line { |l|
    
    l = l.strip
    if l[0,1] == ">"
      motif_name = l[1..-1]# new motif
      report "processing #{motif_name}"
      motif, words, matrix = {}, [], []
    elsif l.empty?
      report "finalizing #{motif_name}"
      motif[:matrix] = matrix unless matrix.empty?
      motif[:words] = words unless words.empty?
      motif[:size] = matrix.empty? ? words[0].size : matrix[0].size
      motifs[motif_name] = motif
      motif = words = matrix = nil
    elsif l.split.size > 1
      # ['A', 'C', 'G', 'T']
      matrix << l.split
    elsif 
      words << l
    end
  }
  
  return motifs
end

report "dmmpmm_indata.rb started, usage <input_file> <result_name> [<result_directory>]"
start __FILE__

exit if ARGV.size < 2

input = IO.read(ARGV[0])
result_name = ARGV[1]

motifs = process_input(input)

wd = ARGV[2] ? ARGV[2] : "DMMPMM_" + Ytilib.time.to_id

Dir.mkdir(wd) unless ARGV[2]
Dir.chdir(wd) {
  Dir.mkdir(result_name)
  Dir.chdir(result_name) {
    motifs.each_key { |factor_name|
      factor_id = factor_name.to_id
      motif = motifs[factor_name]
      Dir.mkdir(factor_id)
      Dir.chdir(factor_id) {
        matrix = motif[:matrix]
        if matrix
          floatm = matrix[0][0].include?(".")
          pm_mx = {}
          pm_mx['A'] = matrix[0].collect { |e| floatm ? e.to_f : e.to_i }
          pm_mx['C'] = matrix[1].collect { |e| floatm ? e.to_f : e.to_i }
          pm_mx['G'] = matrix[2].collect { |e| floatm ? e.to_f : e.to_i }
          pm_mx['T'] = matrix[3].collect { |e| floatm ? e.to_f : e.to_i }
          unless floatm
            pm = PM.new(matrix[0].size, pm_mx)
            # pm.to_pwm! 
          else
            raise "cannot convert PPM(PFM) to PWM"
          end
          
        else
          pm = PM.new_pcm(motif[:words])
        end
        
        motif_bsm = Bismark.new
        motif_bsm.root.add_element("motif", {"id" => "#{factor_id}.MTF", "name" => "#{factor_name}", "length" => motif[:size]})
        pm.to_bismark(motif_bsm.elements["//motif"])
        pm.get_ppm.to_bismark(motif_bsm.elements["//motif"])
        pm.to_pwm!
        pm.to_bismark(motif_bsm.elements["//motif"])
        File.open("#{factor_id}_motif.xml", "w") { |f| f << motif_bsm.getXML }
        system("ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo.rb #{factor_id}_motif.xml #{factor_id}_motif.xml.png #{pm.words_count}")
      }
    }
  }
}