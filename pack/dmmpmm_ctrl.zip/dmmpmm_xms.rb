#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.dirname(File.expand_path(__FILE__))))}/ruby/ytilib/"
require "ytilib.rb"
require "ftools"

def process_input(s)
  xms = REXML::Document.new(s)
  motifs = {}
  xms.elements.each("//motif") { |em|
    name = em.elements["name"].get_text.to_s
    size = em.elements["weightmatrix"].attribute("columns").value.to_i
    pm = PPM.new(size)
    em.elements.each("*/column") { |ec|
      position = ec.attribute("pos").value.to_i
      aprob = ec.elements["weight[@symbol='adenine']"].get_text.to_s
      gprob = ec.elements["weight[@symbol='guanine']"].get_text.to_s
      cprob = ec.elements["weight[@symbol='cytosine']"].get_text.to_s
      tprob = ec.elements["weight[@symbol='thymine']"].get_text.to_s
      pm.matrix['A'][position] = aprob
      pm.matrix['C'][position] = cprob
      pm.matrix['G'][position] = gprob
      pm.matrix['T'][position] = tprob
    }
    motifs[name] = pm
  }
  return motifs
end

report "dmmpmm_xms.rb started, usage <input_file> <result_name> [<result_directory>]"
start __FILE__

exit if ARGV.size < 2
exit if File.ext_wo_name(ARGV[0]) != "xms"

input = IO.read(ARGV[0])
result_name = ARGV[1]

motifs = process_input(input)

wd = ARGV[2] ? ARGV[2] : "DMMPMM_" + Ytilib.time.to_id

Dir.mkdir(wd) unless ARGV[2]
Dir.chdir(wd) {
  Dir.mkdir(result_name)
  Dir.chdir(result_name) {    
    motifs.each_key { |factor_name|
      factor_id = factor_name.to_id
      pm = motifs[factor_name]
      Dir.mkdir(factor_id)
      Dir.chdir(factor_id) {
        motif_bsm = Bismark.new
        motif_bsm.root.add_element("motif", {"id" => "#{factor_id}.MTF", "name" => "#{factor_name}", "length" => pm.size})
        pm.to_bismark(motif_bsm.elements["//motif"])
        File.open("#{factor_id}_motif.xml", "w") { |f| f << motif_bsm.getXML }
        system("ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo.rb #{factor_id}_motif.xml #{factor_id}_motif.xml.png default 100 200 weblogo")
      }
    }
  }
}