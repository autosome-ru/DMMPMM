#!/usr/bin/ruby
require 'cgi'
require 'erb'

def html(file, title, stylesheet)
  r = ""
  
  cgi_start = <<CGI_START
<html>
<head>
  <meta name="generator" content="dmmpmm html core vs Hands & Brain">
  <title>smBsm integrated system - #{title}</title>
  <link rel="stylesheet" href="#{stylesheet}" type="text/css">
</head>
<body>
CGI_START
  r << cgi_start
  
  input = File.read(file)
  eruby = ERB.new(input)
  r << eruby.result(binding())
  
  cgi_end = <<CGI_END
</body>
</html>
CGI_END
  return r << cgi_end
end