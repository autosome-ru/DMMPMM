#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.dirname(File.expand_path(__FILE__))))}/ruby/ytilib/"

require "ytilib.rb"
require "ftools"

require "html.rb"

report "dmmpmm_features_html.rb started, usage <result_directory/dmmpmm_features_result> [bigfoot_mode]"
start __FILE__
exit if ARGV.size == 0
$bifoosig = ARGV[1]

def colorchooser(v,i)
  case i
  when 15
    return " class='red'" if v.to_f > 10
  when 16,17
    return " class='green'" if v.to_f > 10
  when 7 #footprinted sequence count
    return " class='green'" if v.to_f > 16
    return " class='yellow'" if v.to_f > 8
    return " class='orange'" if v.to_f > 4
    return " class='red'"
  end
  ""
end

def convert(v,i)
  return "" if v && v.to_f == 0 && i > 7
  return v unless [1,2,3,4,5,6,10,11,15,16,17,18,19].include?(i)
  return v.to_f.round_to(2)
end

sigma = IO.read(ARGV[0])

$sigma = sigma.split("\n").collect { |s| s.strip }
$headline = $sigma.shift

$set_name = File.name_wo_ext(ARGV[0])
r = html("dmmpmm_features.rhtml", "DMMPMM (#{$set_name}) overall motif features", "../dmmpmm.css")
File.open(File.dirname(ARGV[0]) + '/' + File.name_wo_ext(ARGV[0]) + ".html", "w") { |f| f << r }