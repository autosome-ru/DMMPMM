#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.dirname(File.expand_path(__FILE__))))}/ruby/ytilib/"
require "ytilib.rb"
require "ftools"

report "dmmpmm_shiftcalc.rb started, usage <force_check_revcomp=yes|no> <motif1.xml>..<motifn.xml>"
report "WARNING: kicks all motif to the one strand"
start __FILE__
exit if ARGV.size < 3
force_check_revcomp = ARGV.shift
force_check_revcomp = force_check_revcomp == "true" || force_check_revcomp == "yes"

pms = ARGV

pms.each_with_index { |motif, i|
  next if i == 0
  
  report "checking #{motif} vs #{pms[i-1]}"
  
  pm = PM.from_bismark(Bismark.new(motif).elements["//PPM"], true).to_pwm(1) #was wc, 1 is better in this case
  prev_pm = PM.from_bismark(Bismark.new(pms[i-1]).elements["//PPM"], true).to_pwm(1) #was wc, 1 is better here
  
  ref_sequence = "N"*(pm.size-1) + prev_pm.best_word + "N"*(pm.size-1)
  ref_revcomp = ref_sequence.revcomp
  report "#{ref_sequence}, #{ref_revcomp}, #{pm.best_hit(ref_sequence)}, #{pm.best_hit(ref_revcomp)}}"
  
  if pm.best_hit(ref_revcomp, false) > pm.best_hit(ref_sequence, false)
    report "changing motif orientation"
    `ruby #{Ytilib::PATH_RUBY}by/by_motif2revcomp.rb #{motif} #{motif}`
  end
} if force_check_revcomp

pms = pms.collect { |pm| PM.from_bismark(Bismark.new(pm).elements["//PPM"], true).to_pwm(1) } #was wc, 1 is better in this case

maxs = pms.collect { |pm| pm.size }.max
maxpm = pms.select { |pm| pm.size == maxs }[0]

shifts = []
prevpm = pms[0]
refseq = "N"*maxs + prevpm.best_word + "N"*maxs

pms.each_with_index { |pm, i|
  
  score = pm.best_hit(refseq, false)
  positions = pm.find_hits(refseq, score, false)
  
  report "size=#{pm.size}, hits=#{positions}"
  position = positions.sort { |a,b| (a-maxs).abs <=> (b-maxs).abs }[0]
  shifts << position-maxs
}

shifts.collect { |sh| sh - shifts.min }.each { |sh|
  print "#{sh} "
}