#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.dirname(File.expand_path(__FILE__))))}/ruby/ytilib/"
require "ytilib.rb"

require "ftools"

report "dmmpmm_noyeshd.rb started, usage <result_name> [<result_directory>]"
start __FILE__

exit(2) if ARGV.size < 1
wd = ARGV[1] ? ARGV[1] : "DMMPMM_" + Ytilib.time.to_id
result_name = ARGV[0]

factors = IO.read("indata/noyes_homeo.txt").split(">")[1..-1].collect { |lines|
  lines = lines.split("\n").collect { |l| l.strip }
  {:name => lines.shift, :words => lines.collect { |l| l.upcase }.select { |l| !l.empty? } }
}

Dir.mkdir(wd) unless ARGV[1]
Dir.chdir(wd) {
  Dir.mkdir(result_name) if !File.exist?(result_name)
  Dir.chdir(result_name) {
    factors.each { |factor|
      factor_name = factor[:name]
      factor_id = factor_name.to_id
      
      sequence_count = factor[:words].size
      
      Dir.mkdir(factor_id) unless File.exist?(factor_id)
      Dir.chdir(factor_id) {
        
        Ytilib.write_mfa(factor[:words], "#{factor_id}_motif.mfa")

        system("ruby #{Ytilib::PATH_RUBY}by/by_mfa2motif.rb #{factor_id}_motif.mfa #{factor_id}_motif.xml #{factor_name.cmd_line}")
        
        system("ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo1.rb #{factor_id}_motif.xml #{factor_id}_motif.xml.png #{sequence_count}")
      }
    }
  }
}