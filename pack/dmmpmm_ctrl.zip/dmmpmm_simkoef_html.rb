#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.dirname(File.expand_path(__FILE__))))}/ruby/ytilib/"

require "ytilib.rb"
require "ftools"

require "html.rb"

report "dmmpmm_simkoef_html.rb started, usage <result_directory/dmmpmm_simkoef_result>"
start __FILE__
exit if ARGV.size == 0

def colorchooser(v)
  return " class='red'" if v.to_f > 0.4
  return " class='orange'" if v.to_f > 0.3
  return " class='yellow'" if v.to_f > 0.2
  return " class='green'" if v.to_f > 0.1
  return " class='blue'" if v.to_f > 0.05
  return " class='violet'" if v.to_f > 0.01
  ""
end

simkoef = IO.read(ARGV[0])

$simkoef = simkoef.split("\n")
$headline = $simkoef.shift.split("\t")

$set_name = File.name_wo_ext(ARGV[0])
r = html("dmmpmm_simkoef.rhtml", "DMMPMM (#{$set_name}) similarity comparison using AhoPro P-value calculator", "../dmmpmm.css")
File.open(File.dirname(ARGV[0]) + '/' + File.name_wo_ext(ARGV[0]) + ".html", "w") { |f| f << r }