*** INTRO ***
--> 
    small-BiSMark stands for the small biological sequence markup language.
    The format is still in the heavy development but it is already usable for 
    many purposes.
    
    The format is self-documenting as any other simple xml-based language.
    It doesn't require any specific comments if you do not plan to use
    it for automated database import-export.
    
    Still in this archieve you can find some complex examples of small-BiSMark 
    documents including the ones ready for DB import.
    
*** SAMPLES ***
--> 
    PA_DMEL_motifs.xml - old collections of Drosophila binding factor motifs 
    from D. Papatsenko
    
    PA_DMEL_segments.xml - Drosophila locus and enhancer data from D. Papatsenko
    
    SeSiMCMC-output.xml - a sample of SeSiMCMC Gibbs sampler output
    
    smallbismark-example.xml - simple constructed example intended for 
    illustration of different bismark xml elements
    
*** USAGE ***
--> 
    In DMMPMM project we use elements for motif and matrix
    storage (motif, PWM, PPM etc.) and mapped genome segments.
