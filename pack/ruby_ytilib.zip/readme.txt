*** INSTALLATION ***
0.  Install a Java 6 runtime environment (http://java.sun.com) (for Footstep Bigfoot core)
1.  Install a ruby 1.8 interpreter (http://www.ruby-lang.org/)
2.  Install a fresh version of RMagick 2 (http://rmagick.rubyforge.org/)
3.  Install any fresh gnuplot 4 (http://www.gnuplot.info/)
4.  Make gnuplot binary (wgnuplot.exe in case of Windows) available through 
    your PATH variable.
5.  Download a Drosophila genome assembly (April 2004, dm2) and put
    separate chromosome plain files (chromosome sequence without any 
    delimeters) into the some_dir/store/dmel40

You should follow initial directory structure, i. e.
    some_dir/ruby/ytilib/
    some_dir/ruby/
    ..
    some_dir/extlz/

*** USAGE ***

Now you can use all scripts and tools provided by Ytilib library.
Each tool will print required command-line arguments if called without parameters.

Bigfoot toolset is located ruby/pmenha/ directory.

    bigfoot.rb is intended to create the best multiple local alignment 
               of selected length
    bifooxi.rb tool implements the length selection procedure
    bifoosig.rb calls Bigfoot to make an alignments of lengths in a given range
               and addionally implements two outdated length selection ideas.
               
Bigfoot works with the small-BiSMark format.
One can find bismark-related tools under the ruby/by/ folder.