#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"

report "by_motif2revcomp.rb started, usage: <bismark_file> <revcomp_bismark_file>"
report "TODO: add <word-list> size support"
start __FILE__
exit(2) if ARGV.size < 2
bismark_file, revcomp_bismark_file = ARGV.shift, ARGV.shift

in_bismark = Bismark.new(bismark_file)
motif_name = in_bismark.elements["//motif"].attributes["name"]
motif_id = in_bismark.elements["//motif"].attributes["id"]

bismark = Bismark.new
bmotif = bismark.root.add_element("motif", {"id" => "#{motif_name.to_id}.MTF", "name" => "#{motif_name}"})

#copying important comments in motif tag
in_bismark.elements.each("//motif/comment") { |cm|
  bmotif.add_element(cm)
}

["//PCM","//PPM","//PWM"].each { |mt|
  if in_bismark.elements[mt]
    pm = PM.from_bismark(in_bismark.elements[mt])
    pm.revcomp!
    pm.to_bismark(bmotif)
    if in_bismark.elements[mt].attributes["threshold"]
      bismark.elements[mt].add_attribute("threshold", in_bismark.elements[mt].attributes["threshold"])
    end
  end
}

if in_bismark.elements["//word-list"]
  bm = bismark.elements["//motif"]
  wl = bm.add_element(in_bismark.elements["//word-list"])
  wl.elements.each("//word") { |w| w.text = w.text.revcomp }
end

File.open(revcomp_bismark_file, "w") { |f| f << bismark.getXML }
