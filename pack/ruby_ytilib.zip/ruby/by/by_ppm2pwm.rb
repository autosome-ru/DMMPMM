#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"

report "by_ppm2pwm.rb started, usage: <in_bismark_file> <out_bismark_file> <sequence_count> [<background_ACGT>=default|0.25,0.25,0.25,0.25] [<pseudocount>=1]"
start __FILE__
exit(2) if ARGV.size < 3
bismark_file, out_bismark_file, sequence_count, background, pseudocount = ARGV.shift, ARGV.shift, ARGV.shift.to_i, ARGV.shift, ARGV.shift
background = background && background != "default" ? background.split(",").collect { |av| av.to_f } : [0.25, 0.25, 0.25, 0.25]
background = {'A' => background[0], 'C' => background[1], 'G' => background[2], 'T' => background[3]}

pseudocount = pseudocount ? pseudocount.to_i : 1

in_bismark = Bismark.new(bismark_file)

pm = PM.from_bismark(in_bismark.elements["//PPM"])

pwm = pm.get_pwm(sequence_count, background, pseudocount)

pwm.to_bismark(in_bismark.elements["//motif"])

File.open(out_bismark_file, "w") { |f| f << in_bismark.getXML }