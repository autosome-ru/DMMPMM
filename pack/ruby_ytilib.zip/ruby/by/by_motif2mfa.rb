#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"

report "by_motif2mfa.rb started, usage: <bismark_file> <fasta_file>"
report "TODO: add names support for fasta line-headers"
start __FILE__
exit(2) if ARGV.size < 2
bismark_file, fasta_file = ARGV.shift, ARGV.shift

seqs = []
Bismark.new(bismark_file).elements.each("//word") { |e| seqs << e.get_text.to_s.strip }
Ytilib.write_mfa(seqs, fasta_file)