#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"

report "by_mfa2seg.rb started, usage: <fasta_file> <bismark_file> [<assign_names=false>]"
start __FILE__
exit if ARGV.size < 2

fasta_file, bismark_file, assign_names = ARGV

bismark = Bismark.new
if assign_names
  i = 0
  seqs = Ytilib.read_mfa2hash(fasta_file) { i += 1 }
else
  seqs = Ytilib.read_mfa2hash(fasta_file)
end
segroup = bismark.root.add_element("group", {"size" => seqs.size})

seqs.each_key { |name|
  seg = Segment.new
  seg.location, seg.length, seg.sequence = 0, seqs[name].size, seqs[name]
  seg.to_bismark(segroup).add_attribute("name", name.to_s)
}

File.open(bismark_file, "w") { |f| f << bismark.getXML }

Rekeeper.keepr("BISMARK_OUT", bismark_file, "result of #{fasta_file} conversion to small-BiSMark format")