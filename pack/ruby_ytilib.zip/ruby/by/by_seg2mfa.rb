#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"

report "by_seg2mfa.rb started, usage: <bismark_file> <fasta_file> <genome_release>"
start __FILE__
exit if ARGV.size < 3

bismark = Bismark.new(bismark_file = ARGV.shift)
out_f = File.new(out_f_n = ARGV.shift, "w")
genome_release = ARGV.shift

bismark.elements.each("//segment") { |bsm_seg|
  e = Segment.from_bismark(bsm_seg)
  e.sequence = Seqripper.seqplace(genome_release, e) unless e.sequence
  line = "> #{e.id} #{e.chromosome} #{e.location} #{e.length} #{e.strand}#{$/}#{e.sequence}#{$/}"
  out_f << line
}

out_f.close
Rekeeper.keepr("FASTA_OUT", out_f_n, "#{bismark_file} converted to fasta format using genome_release=#{genome_release}")