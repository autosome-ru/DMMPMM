#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"

report "by_motif2pat.rb started, usage: <in_bismark_file> <out_pat> <matrix_type=PWM|PPM|PCM>"
start __FILE__
exit(2) if ARGV.size < 3
in_bismark_file, out_pat, matrix_type = ARGV

pseudocount = pseudocount ? pseudocount.to_i : 1

in_bismark = Bismark.new(in_bismark_file)

pm = PM.from_bismark(in_bismark.elements["//#{matrix_type}"])

pm.save(out_pat)