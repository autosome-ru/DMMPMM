#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"

report "by_mfa2motif.rb started, usage: <fasta_file> <bismark_file> <motif_name>"
report "TODO: add names support for fasta line-headers"
start __FILE__
exit(2) if ARGV.size < 3
fasta_file, bismark_file, motif_name = ARGV.shift, ARGV.shift, ARGV.shift

seqs = Ytilib.read_mfa2array(fasta_file)
seqs.each { |s| checkerr("sequences of different lengths are supplied for matrix building") { s.length != seqs[0].length } }

pm = PM.new_pcm(seqs, true)

bismark = Bismark.new
bismark.root.add_element("motif", {"id" => "#{motif_name.to_id}.MTF", "name" => "#{motif_name}", "length" => seqs[0].length})

pm.to_bismark(bismark.elements["//motif"])
pm.get_ppm.to_bismark(bismark.elements["//motif"])

# to be sure that PCM was not weighted
bismark.elements.delete_all("//PWM")

pm.to_pwm!.to_bismark(bismark.elements["//motif"])
bi_wl = bismark.elements["//motif"].add_element("word-list", {"size" => seqs.size})
seqs.each { |s|
  bi_wl.add_element("word", {"score" => pm.score(s.upcase)}).add_text(s)
}

File.open(bismark_file, "w") { |f| f << bismark.getXML }