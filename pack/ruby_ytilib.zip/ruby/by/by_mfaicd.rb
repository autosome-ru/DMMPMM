#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"

report "by_mfaicd.rb started, usage: <fasta_file>"
start __FILE__
exit(2) if ARGV.empty?

seqs = Ytilib.read_mfa2array(ARGV[0])
seqs.each { |s| checkerr("sequences of different lengths are supplied for matrix building") { s.length != seqs[0].length } }

pm = PM.new_pcm(seqs)

report "positional information content for motif: #{pm.infocod}"
report "total infocod: #{pm.infocod.inject(0) { |totl, e| totl += e }}"