#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"

report "by_motifs2jaspar.rb started, usage: <dir_w_bismarks> <out_file>"
start __FILE__
exit(2) if ARGV.size < 2

dir, out_f = ARGV
dir = dir.gsub("\\", "/")

out_r = ""

Dir["#{dir}/*.xml"].each { |file|
  report "processing #{file}"
  
  in_bismark = Bismark.new(file)
  next unless in_bismark.elements["//motif"]
  
  if in_bismark.elements["//PCM"]
    pm = PM.from_bismark(in_bismark.elements["//PCM"])
  else
    pm = PM.from_bismark(in_bismark.elements["//PPM"])
  end
  
  motif_name = in_bismark.elements["//motif"].attributes["name"]
  report "motif name: #{motif_name}"
  
  out_r << "> #{motif_name}" << $/
  ['A','C','G','T'].each { |l|
    out_r << pm.matrix[l].inject("") { |s, v| s += "#{v} " } << $/
  }
  out_r << $/
  
}

File.open(out_f, "w") { |f| f << out_r }