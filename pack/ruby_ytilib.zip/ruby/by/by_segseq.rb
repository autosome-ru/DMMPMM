#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"

report "by_segseq.rb started, usage: <bismark_in> <genome_release> <flank_length> <bismark_out>|<fasta_out> [<random_mode>]"
start __FILE__
exit(2) if ARGV.size < 4

bismark_in, genome_release, flank_length, bismark_out = ARGV
bismark_in = Bismark.new(bismark_in)
flank_length = flank_length.to_i

random_mode = ARGV.size > 4
outb_mode = File.ext_wo_name(bismark_out) == "xml"

segs = []
bismark_in.elements.each("//segment") { |e|
  segs << seg = Segment.from_bismark(e)
  seg.location -= flank_length
  seg.length += 2*flank_length
  seg.sequence = Seqripper.seqplace(genome_release, seg).upcase
  
  seg.sequence = Randoom.rand_seq(seg.length) if random_mode
  next unless outb_mode
  
  e.attributes["location"] = seg.location.to_s
  e.attributes["length"] = seg.length.to_s
  e.elements.delete_all("sequence")
  e.add_element("sequence").add_text(seg.sequence)
}

if outb_mode
  File.open(bismark_out, "w") { |f| f << bismark_in.getXML }
else
  Ytilib.write_mfa(segs.collect { |s| s.sequence }, bismark_out)
end