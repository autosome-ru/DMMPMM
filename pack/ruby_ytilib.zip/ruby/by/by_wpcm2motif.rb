#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"

report "by_mfa2motif.rb started, usage: <wpcm_pat_file> <bismark_file> <motif_name>"
report "TODO: add names support for fasta line-headers"
start __FILE__
exit(2) if ARGV.size < 4
ppm_pat, bismark_file, motif_name = ARGV.shift, ARGV.shift, ARGV.shift

pm = PM.load(ppm_pat)
pm = pm.get_ppm

bismark = Bismark.new
bismark.root.add_element("motif", {"id" => "#{motif_name.to_id}.MTF", "name" => "#{motif_name}", "length" => pm.length})

pm.to_bismark(bismark.elements["//motif"])
pm.to_pwm.to_bismark(bismark.elements["//motif"])

File.open(bismark_file, "w") { |f| f << bismark.getXML }