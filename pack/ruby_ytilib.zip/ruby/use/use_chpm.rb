#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"
require 'ftools'

def chipstep(motif_name, out_bismark, params)

  cmdline = "java -Xms268435456 -Xmx1073741824 -cp \"#{Ytilib::PATH_EXTLZ}dnanimals\" Chipmunk #{params}"
  report "running chipmunk-engine: #{cmdline}"
  res = `#{cmdline}`.split("\n")
  
  res.each { |l| report "<Chipmunk> #{l}" }
  if res.last.include?('search failed')
    res = res[-8..-3].collect { |s| s.strip }
    $diagnosis = "found motif with weak gaps or weak borders, stopped on the minimum motif length"
  else
    res = res[-5..-1].collect { |s| s.strip }
    $diagnosis = "ok"
  end
  
  report "best info.co.d. is #{res[0]}"
  a_counts = res[1].split[1..-1].collect { |c| c.to_f }
  c_counts = res[2].split[1..-1].collect { |c| c.to_f }
  g_counts = res[3].split[1..-1].collect { |c| c.to_f }
  t_counts = res[4].split[1..-1].collect { |c| c.to_f }
  
  sc = a_counts[0] + c_counts[0] + g_counts[0] + t_counts[0]
  pm = PM.new(a_counts.size, {'A' => a_counts, 'C' => c_counts, 'G' => g_counts, 'T' => t_counts }, sc)
  
  bismark = Bismark.new
  bismark.root.add_element("motif", {"id" => "#{motif_name.to_id}.MTF", "name" => "#{motif_name}"})
  
  infocod = pm.infocod
  bismark.elements["//motif"].add_element("comment", {"name" => "discrete information content by position"}).add_text(infocod.inspect.to_s)
  total_infocod = infocod.inject(0) { |ttl, icd| ttl += icd }
  bismark.elements["//motif"].add_element("comment", {"name" => "discrete information content"}).add_text(total_infocod.to_s)
  
  pm.get_ppm.to_bismark(bismark.elements["//motif"])
  
  pm.to_pwm!.to_bismark(bismark.elements["//motif"])
  
  File.open(out_bismark, "w") { |f| f << bismark.getXML }
  
  return sc.round
end

report "use_chpm.rb started, usage <motif_name> <out_bismark> <Chipmunk-engine-params>"
start __FILE__

exit(2) if ARGV.size < 3

motif_name, out_bismark = ARGV.shift, ARGV.shift
params = ARGV.inject("") { |pa, pr| pa += "#{pr} " }

sc = chipstep(motif_name, out_bismark, params)
system("ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo.rb #{out_bismark} #{out_bismark}.png #{sc}")

report $diagnosis