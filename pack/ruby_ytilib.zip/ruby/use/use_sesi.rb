#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"

def generate_seqset(real_flank, random_length = 100, caps_mode = "")
  seqset = []  
  entries_fl = $entries_hash
  
  entries_fl.each { |chromosome, entry|
    entry.each { |e|
      location, length, sequence = e
      left_flank = Seqripper.extract($genome_release, chromosome, location - real_flank, real_flank)
      right_flank = Seqripper.extract($genome_release, chromosome, location + length, real_flank)
      sequence.upcase!
      if caps_mode == "one"
        left_flank.downcase!
        right_flank.downcase!
      elsif caps_mode == "all"
        left_flank.upcase!
        right_flank.upcase!
      end
      left_rflank = $n_flank ? "n"*random_length : Randoom.rand_seq(random_length).downcase
      right_rflank = $n_flank ? "n"*random_length : Randoom.rand_seq(random_length).downcase
      seqset << left_rflank + left_flank + sequence + right_flank + right_rflank
    }
  }
  return seqset
end

report "use_sesi.rb started, usage: <bismark_file> <genome_release> <out_motif_file> <motif_name> <max_motif_length> <flank_length> [<absence_prior>=default] [<min_motif_length>] [<random_flank>=100] [<caps>=no|one|all] [<n_flank>=no|yes] [<revcomp_logo>=no|yes]"
report "revcomp logo is not supported in bismark mode"
report "use_sesi IS NOT ALLOWING polyN-s in the resulting SeSiMCMC alignment"
start __FILE__
Rekeeper.flush

exit(2) if ARGV.size < 6

bismark = Bismark.new(bismark_file = ARGV.shift)
$genome_release, out_file, motif_name, max_motif_length, flank_length, absence_prior, min_motif_length, random_flank, caps, $n_flank, revcomp_logo = ARGV
random_flank = random_flank ? random_flank.to_i : 100
background = random_flank > 0 ? "--A 0.25 --C 0.25 --G 0.25 --T 0.25" : ""

caps_mode = caps ? caps : "no"
caps = {"no" => "", "one" => " --caps one", "all" => " --caps all"}[caps]
revcomp_logo = revcomp_logo == "yes" || revcomp_logo == "true" ? revcomp_logo : nil
max_motif_length = max_motif_length.to_i
flank_length = flank_length.to_i
$n_flank = $n_flank && ($n_flank == "yes" || $n_flank = "true")

if absence_prior
  if absence_prior && absence_prior != "default"
    absence_prior = absence_prior.to_f
    Rekeeper.keepp("ABSENCE_PRIOR", absence_prior, "motif absence prior given to SeSiMCMC")
  else
    Rekeeper.keepp("ABSENCE_PRIOR", "default", "motif absence prior given to SeSiMCMC")
    absence_prior = nil
  end
end

absence_prior = absence_prior ? "-p #{absence_prior}" : nil

slow_mode = " -s"
min_motif_length = min_motif_length ? " -l- #{min_motif_length}" : ""

out_fnwoext = File.name_wo_ext(out_file)
out_fextwon = File.ext_wo_name(out_file)
checkerr("unknown output file format") { out_fextwon != "pat" && out_fextwon != "pwm" && out_fextwon != "xml" }

$entries_hash = {}
bismark.elements.each("//segment") { |e|
  seq = e.elements["sequence"].get_text.to_s
  chromosome = e.attributes["chromosome"]
  $entries_hash[chromosome] = [] if $entries_hash[chromosome] == nil
  $entries_hash[chromosome] << [e.attributes["location"].to_i, e.attributes["length"].to_i, seq]
}

# sort by location, deprecated
$entries_hash.each_value { |v| v.sort! { |a,b| a[0] <=> b[0] } }

# generating sequence set and running SeSiMCMC
Rekeeper.keepp("FLANK_LENGTH", flank_length, "sequence flank length used for SeSiMCMC run")
sequence_set = generate_seqset(flank_length, random_flank, caps_mode)

Rekeeper.keepp("MAX_MOTIF_LENGTH", max_motif_length, "maximum allowed motif length for SeSiMCMC run")

set_f_n = "#{File.name_wo_ext(bismark_file)}_#{flank_length}rlf_#{random_flank}rnf.fasta"
#3.b saving final sequence set
Ytilib.write_mfa(sequence_set, set_f_n)
Rekeeper.keepr("SEQUENCE_SET", set_f_n, "sequence set used for motif identification")
Rekeeper.keepp("SEQUENCE_COUNT", sequence_set.size, "sequence number in the set used for motif identification")

# --trim NOW WE THINK IT IS USELESS
# --spaced NOW WE THINK IT IS DANGEROUS
sesimcmc_final = Extlz.sesimcmc(sequence_set, "-r- --adap #{absence_prior} -l+ #{max_motif_length}#{min_motif_length}#{slow_mode}#{caps} #{background}")
File.open("sesimcmc.html", "w") { |f| f << sesimcmc_final.log }
Rekeeper.keepr("SESIMCMC_LOG", "#{out_fnwoext}_sesimcmc.html", "result-file of the SeSiMCMC run")

checkerr("sesimcmc alignment failed") { !sesimcmc_final.ok? }

alignment = sesimcmc_final.alignment

motif = PM.new_pcm(alignment)

Rekeeper.keepp("MOTIF_LENGTH", sesimcmc_final.length, "motif length identified by SeSiMCMC")

if out_fextwon != "xml"
  motif.to_pwm!
  #4.1.a saving alignment & making motif logo
  fasta_f_n, fasta_revcomp_f_n = out_fnwoext + ".fasta", out_fnwoext + "_revcomp.fasta"
  Ytilib.write_mfa(alignment, fasta_f_n, motif_name)
  Rekeeper.keepr("ALIGNMENT", fasta_f_n, "alignment found by SeSiMCMC")

  if revcomp_logo
    #4.1.b saving revcomp alignment & making motif logo
    revcompal = alignment.collect { |seq| seq.complement.reverse }
    Ytilib.write_mfa(revcompal, fasta_revcomp_f_n)
    Rekeeper.keepr("ALIGNMENT_REVCOMP", fasta_revcomp_f_n, "reverse complement for the alignment found by SeSiMCMC")
  end

  #4.2. saving matrix
  motif.save(out_file)
  Rekeeper.keepr("MOTIF", out_file, "resulting motif file")

  #5. plotting matrix logo
  report "making matrix logo"
  system("ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo.rb #{out_file} #{out_file}.png #{sequence_set.size}")
  Rekeeper.keepr("MOTIF_LOGO", "#{out_file}.png", "matrix logo")

  if revcomp_logo
    #6. saving reverse matrix
    motif.revcomp!
    revcomp_f_n = File.name_wo_ext(out_file) + "_revcomp." + File.ext_wo_name(out_file)
    motif.save(revcomp_f_n)
    Rekeeper.keepr("MOTIF_REVCOMP", revcomp_f_n, "resulting reverse complement motif file")

    # 7. making matrix_revcomp logo
    report "making revcomp-matrix logo"
    system("ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo.rb #{revcomp_f_n} #{revcomp_f_n}.png #{sequence_set.size}")
    Rekeeper.keepr("MOTIF_LOGO_REVCOMP", "#{revcomp_f_n}.png", "reverse complement matrix logo")
  end
else
  bismark = Bismark.new
  bismark.root.add_element("motif", {"id" => "#{motif_name.to_id}.MTF", "name" => "#{motif_name}"})
  
  motif.to_bismark(bismark.elements["//motif"])
  
  motif.get_ppm.to_bismark(bismark.elements["//motif"])
  
  # to be sure that PCM was not weighted
  bismark.elements.delete_all("//PWM")
  motif.to_pwm!.to_bismark(bismark.elements["//motif"])
  
  File.open(out_file, "w") { |f_b| f_b << bismark.getXML }
  Rekeeper.keepr("MOTIF", out_file, "resulting motif file")
  
  system("ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo.rb #{out_fnwoext}.xml #{out_fnwoext}.xml.png #{sequence_set.size}")
  Rekeeper.keepr("MOTIF_LOGO", "#{out_fnwoext}.xml.png", "motif logo")
end