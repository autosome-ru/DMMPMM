#!/usr/bin/ruby
module Ytilib

require 'ytilib.rb'

class Seqripper

private 
  def Seqripper.form_path(genome, chromosome)
    "#{Ytilib::PATH_STORE}#{genome}/#{chromosome}.plain"
  end

public
  def initialize(genome, chromosome)
    path = Ripper.form_path(genome, chromosome)
    @path, @file = path, File.new(path)
  end
  
  def set_path(path)
    @path, @file = path, File.new(path)
  end
  
  def extract(start, length, strand=Ytilib::STRAND_DIRECT)
    @file.seek(start-1)
    sequence = @file.read(length)
    return strand == Ytilib::STRAND_REVCOMP ? sequence.compl!.reverse : sequence
  end
  
  def read
    @file.seek(0)
    return @file.read
  end
  
  def Seqripper.extract(genome, chromosome, start, length, strand=Ytilib::STRAND_DIRECT)
    file = File.new(form_path(genome, chromosome))
    file.seek(start-1)
    sequence = file.read(length)
    file.close
    return strand == Ytilib::STRAND_REVCOMP ? sequence.compl!.reverse : sequence
  end
  
  def Seqripper.seqplace(genome, p1)
    file = File.new(form_path(genome, p1.chromosome))
    file.seek(p1.location-1)
    sequence = file.read(p1.length)
    file.close
    return p1.strand == Ytilib::STRAND_REVCOMP ? sequence.compl!.reverse : sequence
  end
  
end

end