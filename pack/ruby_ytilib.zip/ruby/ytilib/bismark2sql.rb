#!/usr/bin/ruby

module Ytilib

require "ytilib.rb"

class Bismark2sql < Bismark
  
  NAMEID_H = {"name" => "name", "id" => "id"}
  BISMARK2SQL = {
    # name => TABLE, attributes, inner_TEXT_ONLY_elements
    # all additional processing should be done in the corresponding functions
    "factor" => ["factor", {}.merge!(NAMEID_H), 
                  {"comment" => "comment", "description" => "description"}],
    "species" => ["species", {"scientific-name" => "scientific_name", "common-name" => "common_name"}.merge!(NAMEID_H)],
    "source" => ["source", {"author" => "author", "year" => "year", "species-id" => "species_id", "motif-id" => "motif_id", "chromosome" => "chromosome",
                  "genome-release" => "genome_release", "factor-name" => "factor_name", "source-id" => "source_id", "type" => "type"}.merge!(NAMEID_H), 
                  {"description" => "description", "reference" => "reference", "comment" => "comment"}],
    "segment" => ["segment", {"chromosome" => "chromosome", "strand" => "strand", "location" => "location",
                  "length" => "length", "type" => "type", "source-id" => "source_id", "locus-name" => "locus_name", "quality" => "quality", 
                  "segment-id" => "segment_id", "species-id" => "species_id", "genome-release" => "genome_release", "original-id" => "original_id", "factor-name" => "factor_name"}.merge!(NAMEID_H),
                  {"sequence" => "sequence", "description" => "description", "reference" => "reference", "comment" => "comment"}],
    "word" => ["word", {"source-id" => "source_id", "name" => "name", "motif-id" => "motif_id", "species-id" => "species_id", "factor-name" => "factor_name", "score" => "score"}],
    "motif" => ["motif", {"source-id" => "source_id", "species-id" => "species_id", "factor-name" => "factor_name", "original-id" => "original_id", 
                  "length" => "length", "words-count" => "words_count"}.merge!(NAMEID_H), 
                  {"consensus" => "consensus", "reg-exp" => "reg_exp", "description" => "description", "reference" => "reference", "comment" => "comment"}],
    "regulator" => ["regulator", {"factor-name" => "factor_name", "target-name" => "target_name", "id" => "id", "segment-id" => "segment_id", "type" => "type",
                    "source-id" => "source_id", "species-id" => "species_id", "original-id" => "original_id"}, 
                  {"description" => "description", "reference" => "reference", "comment" => "comment"}],
    "PWM" => ["pm", {"source-id" => "source_id", "name" => "name", "motif-id" => "motif_id", "factor-name" => "factor_name", "threshold" => "threshold"}],
    "PCM" => ["pm", {"source-id" => "source_id", "name" => "name", "motif-id" => "motif_id", "factor-name" => "factor_name", "threshold" => "threshold"}],
    "PPM" => ["pm", {"source-id" => "source_id", "name" => "name", "motif-id" => "motif_id", "factor-name" => "factor_name", "threshold" => "threshold"}]
  }
  
  def initialize(path = nil, add_dtd = false, verbose = false)
    @verbose = verbose
    super(path, add_dtd)
  end
  
  def sqlize_string(s)
    checkerr("string for sql conversion contains apostrophe") { s.scan(/[']/).size > 0 }
    # (/\(\)/=~s designed for SQL functions handling, like NOW()
    s.empty? ? "NULL" : (/\(\)/=~s ? "#{s}" : "'#{s}'")
  end
  
  def sqilze2values(vals_h)
    keys = vals_h.keys
    key0 = keys.shift
    ret = "(#{key0}"
    keys.each { |name| ret << ", #{name}" }
    ret << ") VALUES('#{vals_h[key0]}'"
    keys.each { |name| ret << ", #{sqlize_string(vals_h[name])}" }
    ret << ")"
  end
  
  def gather_els(element, names)
    ret = {}
    return ret if names == nil
    names.each_key { |xmlname| 
      element.elements.each(xmlname) { |ee|
        if ret[names[xmlname]] == nil
          ret[names[xmlname]] = ee.get_text.to_s
        else
          ret[names[xmlname]] << '\n' << ee.get_text.to_s
        end
      }
    }
    return ret
  end
  
  def gather_atts(element, names)
    ret = {}
    names.each_key { |xmlname| 
      if (av = element.attributes[xmlname]) != nil
        ret[names[xmlname]] = av
      else
        (@att_stack.size-1).downto(0) { |i|
          if (nf_s = @att_stack[i][xmlname]) != nil
            ret[names[xmlname]] = nf_s
            break
          end
        }
      end
    }   
    return ret
  end
  
  def deep_sqlize(element, add_values = {})
    b2s = BISMARK2SQL[element.name]
    add_values[b2s[3]] = element.get_text.value.strip if b2s[3] != nil
    sql_s = "INSERT INTO #{b2s[0]} #{sqilze2values(gather_atts(element, b2s[1]).merge!(gather_els(element, b2s[2])).merge!(add_values))}; #{$/}"
  end
  
  def deep_sqlize_matrix(matrix)
    sql = ""
    matrix.each_element { |e|
      checkerr("bad element inside matrix #{e.name}") { e.name != "pm-column" }
      a, c, g, t = e.elements["a"].get_text.to_s, e.elements["c"].get_text.to_s, e.elements["g"].get_text.to_s, e.elements["t"].get_text.to_s
      position = e.attributes["position"]
      add_values = {"a" => a, "c" => c, "g" => g, "t" => t, "position" => position, "type" => matrix.name}
      sql << deep_sqlize(matrix, add_values)
    }
    return sql
  end
  
  def deep_sqlize_wordlist(wordlist)
    sql = ""
    wordlist.each_element { |e|
      sql << deep_sqlize(e, {"sequence" => e.get_text.to_s})
    }
    return sql
  end
    
  def process(e, level = 0, sql = "")
    report("-"*(level) + e.name + e.attributes.keys.inspect) if @verbose
    case e.name
      when "factor", "species", "regulator"
        sql << deep_sqlize(e)
      when "segment"
        sql << deep_sqlize(e)
        # support for inner segments and regulators
        corr_att = e.attributes.dup
        corr_att["segment-id"] = e.attributes["id"]
        @att_stack << corr_att
          e.each_element{ |ee| process(ee, level+1, sql) }
        @att_stack.pop        
      when "source"
        sql << deep_sqlize(e, {"stamp" => "NOW()"})
      when "smallbismark"
        e.each_element { |ee| process(ee, level+1, sql) }
      when "group"
        if e.elements.size > 0
          @att_stack << e.attributes
          e.each_element{ |ee| process(ee, level+1, sql) }
          @att_stack.pop
        end
      when "motif"
        sql << deep_sqlize(e)
        corr_att = e.attributes.dup
        corr_att["motif-id"] = e.attributes["id"]
        @att_stack << corr_att
          e.each_element{ |ee| process(ee, level+1, sql) }
        @att_stack.pop        
      when "word-list"
        sql << deep_sqlize_wordlist(e)
      when "PWM", "PCM", "PPM"
        sql << deep_sqlize_matrix(e)
      end
    return sql
  end
  
  def sqlize(out_path = nil)
    @att_stack = []
    if out_path != nil
      File.open(out_path, "w+") { |f| f << process(root) } 
    else
      return "" << process(root)
    end
  end
  
  def getSQL(out_path = nil)
    return sqlize(out_path)
  end
  
  def Bismark2sql.sqlize(in_path, out_path)
    sqler = Bismark2sql.new(in_path)
    sqler.sqlize(out_path)
  end
 
end

end