#!/usr/bin/ruby
class Distroboo
  def initialize(data, col_number = 100, randomize = false)
    Kernel.srand if randomize
    
    @total_count = data.size
    @left_border, @right_border = data.min.to_f, data.max.to_f
    
    if @left_border == @right_border
      @genhist = [@left_border]
      return
    end
    
    @length = @right_border - @left_border
    @step = @length/col_number
    # [left, middle, right]
    @diaps = (0...col_number).to_a.collect { |i| [ @left_border + i*@step, @left_border + (i+0.5)*@step, @left_border + (i+1)*@step] }
    
    @hist = Array.new(@diaps.size + 1)
    @hist.fill(0)
    @total_count = data.size
    data.each { |d|
      
      index = ( (d - @left_border) / @step).floor
      @hist[index] += 1
    }
    
    @hist[-2] += @hist.last
    @hist.pop
    
    # here we need to convert @hist to appopriate form
    @genhist = Array.new(@total_count)
    j, imm_c = 0, 0
    (0...@total_count).each { |i|
      
      if imm_c < @hist[j]
        imm_c += 1
      else
        
        while imm_c >= @hist[j] do
          imm_c = 0
          j += 1
        end
        imm_c += 1
      end
      
      @genhist[i] = @diaps[j][1]
      
    }
    
  end
  
  def rnd
    @genhist[rand(@genhist.size)]
  end
  
  def gather
    (0...@total_count).collect { rnd }
  end
  
  def histogram
    result = []
    @diaps.each_with_index { |diap, i|
      result << {:left => diap[0], :right => diap[2], :value => @hist[i]}
    }
    return result
  end
end