#!/usr/bin/ruby
module Ytilib

class Seqplace
  
  attr_accessor :location, :length, :chromosome, :strand
  alias loc location
  alias chr chromosome
  alias chrom chromosome
  alias len length
  
  def initialize(chromosome = nil, location = nil, length = nil, strand = Ytilib::STRAND_DIRECT)
    @location, @length, @chromosome, @strand = location, length, chromosome, strand
  end
  
  def to_bismark(b)
  	atts = {"location" => @location, "length" => @length}
  	atts["chromosome"] = @chromosome if chromosome && !chromosome.empty?
  	atts["strand"] = @strand if strand && !strand.empty?
    s = b.add_element("segment", atts)
    return s
  end
  
  def from_bismark(e)
    checkerr("bad tag given to seqplace bismark parser: #{e.name}") { e.name != "segment" }
    @location, @length, @chromosome, @strand = e.attributes["location"].to_i, e.attributes["length"].to_i, e.attributes["chromosome"], e.attributes["strand"]
    @chromosome = nil if @chromosome && @chromosome.empty?
    @strand = nil if @strand && @strand.empty?
    return self
  end
  
  def Seqplace.from_bismark(e)
    return Seqplace.new.from_bismark(e)
  end
  
  def dup
    return Seqplace.new(@chromosome, @location, @length, @strand)
  end
  
end

class Segment < Seqplace
  
  attr_accessor :sequence, :id
  alias seq sequence
  
  def initialize(chromosome = nil, location = nil, length = nil, strand = Ytilib::STRAND_DIRECT, id = nil, sequence = nil)
    super(chromosome, location, length, strand)
    @sequence, @id = sequence, id
  end  
  
  def to_bismark(b)    
    s = super(b)
    s.add_attribute("id", @id)
    s.add_element("sequence").add_text(@sequence) if @sequence && !@sequence.empty?
    return s
  end
  
  def from_bismark(e)
  	super(e)
    @id = e.attributes["id"]
    @sequence = e.elements["sequence"].get_text.to_s.strip if e.elements["sequence"] != nil
    @sequence = nil if @sequence && @sequence.empty?
    return self
  end
  
  def Segment.from_bismark(e)
    return Segment.new.from_bismark(e)
  end
  
  def dup
    return Segment.new(@chromosome, @location, @length, @stramd, @id, @sequence)
  end
  
end

end