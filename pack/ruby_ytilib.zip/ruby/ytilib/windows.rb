#!/usr/bin/ruby
module Ytilib
  DUMMY = :dummy
  MYSQL_UNIX_ADDR = DUMMY
  MYSQL_HOST = "localhost"
  MYSQL_USER = "root"
  MYSQL_PASSWORD = ""
  PATH_GLOBAL = File.dirname(File.dirname(File.dirname(__FILE__))) + "\\"
  PATH_STORE = PATH_GLOBAL + "store\\"
  PATH_EXTLZ = PATH_GLOBAL + "extlz\\"
  PATH_SESIMCMC = PATH_EXTLZ + "SeSiMCMC.exe"
  PATH_AHOPRO = PATH_EXTLZ + "Karas.exe"
  PATH_BLAT = DUMMY
  PATH_RUBY = PATH_GLOBAL + "ruby\\"
  PATH_YTILIB = PATH_RUBY + "ytilib\\"
  FONT_GDDEFAULT = 'Arial'
  FONT_GDFONTPATH = DUMMY
  PATH_GNUPLOT = 'wgnuplot.exe'
  
  def Ytilib.require_rmagick
    $: << "C:/ruby/lib/ruby/gems/1.8/gems/rmagick-2.9.0-mswin32/ext/"
    require 'C:/ruby/lib/ruby/gems/1.8/gems/rmagick-2.9.0-mswin32/lib/RMagick.rb'
  end
end