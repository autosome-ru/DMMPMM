#!/usr/bin/ruby
module Ytilib

require 'yaml'

class Rekeeper
  
  def initialize
    report "TODO: move from global variables to class variables"
    checkerr("there can be only one Rekeeper") { $keepbox != nil }
    $keepbox = File.exist?("llib.yaml") ? YAML::load_file("llib.yaml") : {}
    $keepbox = $keepbox ? $keepbox : {}
    ObjectSpace.define_finalizer( self, Rekeeper.final )
  end
  
  def Rekeeper.clear
  	$keepbox = {}
  end
  
  def Rekeeper.reinit
    new_box = File.exist?("llib.yaml") ? YAML::load_file("llib.yaml") : {}
    new_box = new_box ? new_box : {}
    $keepbox = $keepbox.merge(new_box)
  end
  
  def Rekeeper.flush
    unless $keepbox.empty?
      old_box = File.exist?("llib.yaml") ? YAML::load_file("llib.yaml") : {}
      old_box[$program_name] = $keepbox[$program_name] if $keepbox.has_key?($program_name)
      
      $keepfile = File.new("llib.yaml", "w")
      YAML::dump(old_box, $keepfile)

      $keepfile.close
    end
  end
  
  def Rekeeper.final
    lambda {
      unless $keepbox.empty?
        old_box = File.exist?("llib.yaml") ? YAML::load_file("llib.yaml") : {}
        old_box[$program_name] = $keepbox[$program_name] if $keepbox.has_key?($program_name)
        
        $keepfile = File.new("llib.yaml", "w")
        YAML::dump(old_box, $keepfile)

        $keepfile.close
      end
    }
  end
  
  def keep_parameter(name, value, description, program_name = $program_name)
    $keepbox[program_name] = {} unless $keepbox[program_name]
    $keepbox[program_name][name] = {:value => value, :description => description}
  end
  alias keepp keep_parameter
  
  def keep_resource(name, path, description, program_name = $program_name)
    $keepbox[program_name] = {} unless $keepbox[program_name]
    $keepbox[program_name][name] = {:path => path, :description => description}
  end
  alias keepr keep_resource
  
  def Rekeeper.keepr(p1, p2, p3)
    $rekeeper.keepr(p1, p2, p3)
  end
  
  def Rekeeper.keepp(p1, p2, p3)
    $rekeeper.keepp(p1, p2, p3)
  end
  
  def Rekeeper.get(program, id)
    return nil unless $keepbox["[#{program}]"]
    $keepbox["[#{program}]"][id]
  end
  
end

$rekeeper = Rekeeper.new

class Rereader
  def initialize(path=".")
    @box = File.exist?("#{path}/llib.yaml") ? YAML::load_file("#{path}/llib.yaml") : {}
  end
  
  def get(program, id)
    return nil unless @box["[#{program}]"]
    @box["[#{program}]"][id]
  end
end

end