#!/usr/bin/ruby
module Ytilib
  class PM
    def score_sigma(trycount = 4**10, approx = false)
      
      scores = []
      if @size <= 10 && !approx
        (0...4**@size).each { |i| 
          word = i.to_s(4).rjust(@size, "0").tr("0123", "ACGT")
          scores << score(word)
        }
      else
        trycount.times {
          word = Randoom.rand_seq(@size)
          scores << score(word)
        }
      end
      sum1 = scores.inject(0) { |sum,s| sum += s }
      mean = sum1 / scores.size
      
      sum2, sumc = 0, 0
      scores.each { |score|
        sum2 += (score-mean)**2
        sumc += (score-mean)
      }
      variance = (sum2 - sumc**2 / scores.size) / (scores.size-1)
      
      sigma = Math.sqrt(variance)
      if block_given?
        yield(sigma, mean)
      end
      
      return sigma
    end
  
  end
end