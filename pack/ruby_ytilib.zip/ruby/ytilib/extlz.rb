#!/usr/bin/ruby

module Ytilib

report "add global soloist support to use in conjuction with Opera House", "extlz"
report "blat functions use 'what' 'where' syntax instead of 'database' 'sequence' for command-line blat"
report "temporary file path is fixed during single run"
report "identity calculation for blat is not working for alignment with gaps"
report "error handling for SeSiMCMC is not finalized"
report "memory limit of 1Gb is used on Linux for P-value calculation"

module Extlz      
  
  class SeSiMCMC
    attr_reader :length, :alignment, :log
    
    def initialize(seqs, argv)
      @length, @alignment = 0, []
      @sequences, @argv = seqs, argv
      @ok = true
      @log = ""
    end
    
    def ok?
      return @ok
    end
    
    def run
      @ok = @sequences.size > 1
      return if !@ok
      @length = 0
      temp = Extlz.make_temp(SESIMCMC_TEMP)
      Ytilib.write_mfa(@sequences, temp)
      report "starting SeSiMCMC #{@argv.inspect} -i #{temp} -html -k 0 -ssb"
      sesimcmc = `#{Ytilib::PATH_SESIMCMC} -i #{temp} #{@argv} -html -k 0 -ssb`
      File.delete(temp)
      @log = sesimcmc
      @ok = sesimcmc.scan(/is \d+/).size > 0
      return if !@ok
      # won't work in case of trim mode
      # @length = sesimcmc.scan(/the site length found is \d+/)[0].scan(/\d+/)[0].to_i
      #sesimcmc.split($/).each { |line|
      #  @ok = !(line.split(/<|>/).size == 2 && line.split(/<|>/)[1].split[1] == nil)
      #  return unless @ok
      #  @alignment << line.split(/<|>/)[1].split[1].strip if line.split(/<|>/).size == 2
      # }
      # not working on spaced sites
      
      table = sesimcmc.scan(/The description of sites.+?<\/table>/m)
      table_rows = table.last.scan(/<tr>.+?<\/tr>/m)
      return unless @ok = (table_rows.size > 1)
      table_rows[1..-1].each { |tr|
      	seq = tr.scan(/>[ATGCNnatgc]+</)
      	seq[seq.size/2..-1].inject("") { |seq, s| seq += s[1..-2] }
      	@alignment << seq
      }
      @length = @alignment.last.size
    end
    
  end
  
  def Extlz.sesimcmc(seqs, argv)
   sesimcmc = SeSiMCMC.new(seqs, argv)
   sesimcmc.run
   return sesimcmc
  end
  
  def Extlz.p_value(pms, thresholds, length, complement=true, prob = Randoom::DEF_PROBS, verbose=false, thrhexmode=true, counts=nil)

    checkerr("no threshold given") { !thresholds }
    checkerr("thresholds.size != pms.size") { pms.is_a?(Array) && thresholds.size != pms.size }
    checkerr("counts.size != pms.size") { pms.is_a?(Array) && counts.size != pms.size }

    mem_cut = Ytilib::OS == :LINUX ? "ulimit -v #{1024*8} -m #{1024*1024}; " : ""

    ahopro = ""
    if pms.is_a?(Array)
      pat_files = pms.collect { Extlz.make_temp(AHOPRO_TEMP) }
      pat_files.each_with_index { |f_n, i| pms[i].save(f_n) }
      Extlz.make_temp(AHOPRO_TEMP1) { |prob_fn|
        File.open(prob_fn, "w") { |prob_f|
          prob_f << ["A","C","G","T"].inject("") { |s, v| s += "#{prob[v]} "}
        }
        matrices = (0...pat_files.size).inject("") { |mat, i| mat += " #{pat_files[i]} #{counts ? counts[i] : 1} #{thrhexmode ? float2hex(thresholds[i]) : thresholds[i]}" }
        ahopro = "#{mem_cut}#{Ytilib::PATH_AHOPRO} -prob #{prob_fn} -kocc #{pms.size}#{matrices} #{complement ? '-complement' : ''} -len #{length}"
        report "starting #{ahopro}" if verbose
        ahopro = `#{ahopro}`
        ahopro.each_line { |l|
          report "<ahopro> #{l.strip}"
        } if verbose
      }
      pat_files.each { |f_n| File.delete(f_n) }
    else
      Extlz.make_temp(AHOPRO_TEMP, AHOPRO_TEMP1) { |pat_fn, prob_fn|
        File.open(prob_fn, "w") { |prob_f|
          prob_f << ["A","C","G","T"].inject("") { |s, v| s += "#{prob[v]} "}
        }
        pms.save(pat_fn)
        ahopro = "#{Ytilib::PATH_AHOPRO} -prob #{prob_fn} -kocc 1 #{pat_fn} #{counts ? counts : 1} #{thrhexmode ? float2hex(thresholds) : thresholds} #{complement ? '-complement' : ''} -len #{length}"
        report "starting #{ahopro}" if verbose
        ahopro = `#{ahopro}`
        ahopro.each_line { |l|
          report "<ahopro> #{l.strip}"
        } if verbose
      }
    end
    result = ahopro.scan(/P-value = \d+\.?\d*[e]?-?\d*/)[0]
    return result unless result
    result = result.split[2].to_f
    report "found P-value=#{result}" if verbose
    result
  end
  
  def Extlz.blat_w_path(b_seq, path, fast_map = true)
    temp = make_temp(BLAT_TEMP1)
    Ytilib.write_mfa({"b_seq" => b_seq}, temp)
    blat_result = blat_path_w_path(temp, path, fast_map, b_seq.size)
    File.delete(temp)
    return blat_result
  end
  
  def Extlz.blat_w_seq(b_seq, seq, fast_map = true)
    temp1 = make_temp(BLAT_TEMP1)
    temp2 = make_temp(BLAT_TEMP2)
    Ytilib.write_mfa({"b_seq" => b_seq}, temp1)
    Ytilib.write_mfa({"seq" => seq}, temp2)
    blat_result = blat_path_w_path(temp1, temp2, fast_map, b_seq.size)
    File.delete(temp1)
    File.delete(temp2)
    return blat_result
  end
  
  def Extlz.blat_path_w_path(b_seq_path, path, fast_map, seq_size)
    temp = make_temp(BLAT_TEMP)
    blat = `#{Ytilib::PATH_BLAT} #{path} #{b_seq_path} #{temp} -noHead #{fast_map ? '-fastMap' : ''}`
    blat.each_line { |l|
      report "<blat> #{l.strip}"
    }
    blat_result = blat_gather(IO.read(temp), seq_size)
    File.delete(temp)
    return blat_result
  end
  
  def Extlz.blat_w_genome(b_seq, genome, chromosome_list, fast_map=true)
    result = []
    temp = make_temp(BLAT_TEMP1)
    Ytilib.write_mfa({"b_seq" => b_seq}, temp)
    chromosome_list.each { |chrom_name|
      report "processing chromosome #{chrom_name}"
      result_c = blat_path_w_path(temp, "#{Ytilib::PATH_STORE}#{genome}/#{chrom_name}.fasta", fast_map, b_seq.size)
      result_c.each { |r| r.chromosome = chrom_name }
      result.concat(result_c)
    }
    File.delete(temp)
    result.sort! { |a,b| b.match <=> a.match }
    return result
  end
  
  class Blathit < Seqplace
    attr_accessor :match, :identity
    def initialize(match, identity, location, length, strand)
      super(nil, location, length, strand)
      @match, @identity = match, identity
    end
  end
  
  def Extlz.make_temp(s0, s1=nil, s2=nil)
    unless block_given?
      checkerr("make_temp can't work with many args without block") { s1 }
      return temp_str(s0)
    else
      result = nil
      if s2
        result = yield(s0=temp_str(s0), s1=temp_str(s1), s2=temp_str(s2))
      elsif s1
        result = yield(s0=temp_str(s0), s1=temp_str(s1))
      elsif s0
        result = yield(s0=temp_str(s0))
      end
      File.delete(s0) if s0
      File.delete(s1) if s1
      File.delete(s2) if s2
      return result
    end
  end
  
  def Extlz.temp_str(s)
    s ? "#{rand(99)}#{rand(99)}#{rand(99)}_#{@@counter += 1}_#{Ytilib.time.to_id}_#{s}" : s
  end

private

  @@counter = -1
  
  SESIMCMC_TEMP = "extlz_sesimcmc.fasta"
  AHOPRO_TEMP = "extlz_ahopro.pat"
  AHOPRO_TEMP1 = "extlz_ahopro.prob"
  BLAT_TEMP = "extlz_blat.psl"
  BLAT_TEMP1 = "extlz_blat1.fasta"
  BLAT_TEMP2 = "extlz_blat2.fasta"
    
  def Extlz.blat_gather(s, seq_size)
    result = []
    s.each_line { |line|
      l = line.split
      len, strand = l[16].to_i - l[15].to_i, l[8] == "+" ? Ytilib::STRAND_DIRECT : Ytilib::STRAND_REVCOMP
      result << Blathit.new(l[0].to_i, l[0].to_f/seq_size, l[15].to_i + 1, len, strand)
    }
    result.sort! { |a,b| b.match <=> a.match }
    return result
  end
  
  def Extlz.float2hex(thresh)
    # ["4029d999d525c2e9".to_i(16)].pack('Q').unpack('E')
    
    thresh = "0x" + ([thresh].pack('E').unpack('Q')[0] - 137).to_s(16)
    # report thresh
    # report [thresh.to_i(16)].pack('Q').unpack('E')
    
    return thresh
    
  end
end

end