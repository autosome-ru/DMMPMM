#!/usr/bin/ruby
module Ytilib

module Plainer
  def Plainer.fasta2plain(path, mask)
    old_dir = Dir.pwd
    Dir.chdir(path)
    Dir[mask].each { |name|
      fasta = IO.read(name)
      plain = File.new(File.basename(name)[/\w+/] + ".plain", "w+")
      fasta.each_line { |line|
        plain << line.strip if line.strip[0,1] != ">"
      }
      plain.close
    }
  end
end

end