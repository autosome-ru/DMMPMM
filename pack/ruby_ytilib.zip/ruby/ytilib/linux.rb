#!/usr/bin/ruby
module Ytilib
  DUMMY = :dummy
  MYSQL_UNIX_ADDR = "/var/run/mysqld/mysqld.sock"
  MYSQL_HOST = "localhost"
  MYSQL_USER = "root"
  MYSQL_PASSWORD = ""
  PATH_GLOBAL = "/home/llib/Gbx/"
  PATH_STORE = PATH_GLOBAL + "store/"
  PATH_EXTLZ = PATH_GLOBAL + "extlz/"
  PATH_SESIMCMC = PATH_EXTLZ + "SeSiMCMC"
  PATH_BLAT = PATH_EXTLZ + "blat"
  PATH_AHOPRO = PATH_EXTLZ + "ahokocc"
  PATH_RUBY = PATH_GLOBAL + "ruby/"
  PATH_YTILIB = PATH_RUBY + "ytilib/"
  FONT_GDDEFAULT = 'FreeSansBold'
  FONT_GDFONTPATH = '/usr/share/fonts/truetype/freefont/'
  PATH_GNUPLOT = "GDFONTPATH=\"#{Ytilib::FONT_GDFONTPATH}\" gnuplot"
  
  def Ytilib.require_rmagick
    require 'RMagick'
  end
end