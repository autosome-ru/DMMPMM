#!/usr/bin/ruby
module Ytilib

class Gnuphist
  
  attr_accessor :main_title, :y_title, :addon, :bmargin, :keyplace
  
  def initialize(data_hash, name, main_title = '', x_ticks = nil, titles_order = nil)
  	@addon, @bmargin, @keyplace = nil, 5, 'left'
    if x_ticks != nil
      @data = data_hash
      @titles = titles_order ? titles_order : data_hash.keys.sort
      @name, @x_ticks = name, x_ticks
      @main_title = main_title
      File.open("#{name}.data", "w") { |f|
        @x_ticks.each_with_index { |x, i| 
          f << x
          @titles.each { |title|
            f  << " " << @data[title][i]
          }
          f << $/
        }      
      }
    else
      @data = data_hash
      @titles = [main_title]
      @x_ticks = data_hash.keys.sort
      @name, @main_title = name, main_title
      File.open("#{name}.data", "w") { |f|        
        @x_ticks.each { |tick|
          f  << tick << " " << @data[tick] << $/
        }        
      }
      @add = "set nokey"
    end
  end
  
  def makeplot
    plotf = File.new("#{@name}.plot", "w")
    plotf.puts "set terminal png small font #{Ytilib::FONT_GDDEFAULT} 14 size 1600, 1200"
    plotf.puts "set key #{@keyplace}"
    plotf.puts "set grid"
    plotf.puts "set title '#{@main_title}'"
    plotf.puts "set ylabel '#{@y_title}'"
    plotf.puts "set xtics nomirror rotate by 90"
    plotf.puts "set bmargin #{@bmargin}"
    plotf.puts "set style data histogram"
    plotf.puts "set style histogram cluster gap 1"
    plotf.puts "set style fill solid border -1"
    plotf.puts "set output '#{@name}.png'"    
    plotf.puts @add if @add != nil
    plotf.puts @addon if @addon != nil
    plotf << "plot '#{@name}.data' "    
    k0 = @titles.shift
    plotf << "using 2:xtic(1) t '#{k0}'"
    @titles.each_with_index { |k, i|
      plotf << ", '' using #{i+3} t '#{k}'"
    }
    plotf.close    
    gnuphist = `#{Ytilib::PATH_GNUPLOT} #{@name}.plot`
    gnuphist.each_line { |l|
      report "<gnuplot> #{l.strip}"
    }
    Rekeeper.keepr(@name.to_id, "#{@name}.png", @main_title)
  end
end

end