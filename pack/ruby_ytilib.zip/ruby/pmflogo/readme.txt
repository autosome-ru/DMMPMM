pmflogo  - stable version
pmflogo1 - development version, uses discrete information content levels instead of background grid