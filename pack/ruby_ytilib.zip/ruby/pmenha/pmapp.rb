#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"
require "#{File.dirname(File.expand_path(__FILE__))}/pmento.rb"

report "pmapp.rb started, usage <pwm_bismark> <seq_bismark> <genome_release> <flank_length> <out_bismark>"
start __FILE__
exit(2) if ARGV.size < 5

pwm_bismark, seq_bismark = Bismark.new(ARGV[0]), Bismark.new(ARGV[1])
genome_release, flank_length = ARGV[2], ARGV[3].to_i
out_bismark = ARGV[4]

motif_name = pwm_bismark.elements["//motif"].attributes["name"]
pm = PM.from_bismark(pwm_bismark.elements["//PWM"])

segs = []
seq_bismark.elements.each("//segment") { |e|
  segs << seg = Segment.from_bismark(e)
  seg.location -= flank_length
  seg.length += 2*flank_length
  seg.sequence = Seqripper.seqplace(genome_release, seg).upcase
}

segs.each { |seg|
  s = seg.sequence.dup
  seg.sequence.downcase!
  
  max_score = (0..(s.size - pm.size)).collect { |i|
    seq, seq_rc = s[i, pm.size], s[i, pm.size].revcomp!
    [pm.score(seq), pm.score(seq_rc)].max
  }.max
  
  (0..(s.size - pm.size)).each { |i|
    seq, seq_rc = s[i, pm.size], s[i, pm.size].revcomp!
    seg.sequence[i,pm.size] = s[i,pm.size].upcase if ([pm.score(seq), pm.score(seq_rc)].max - max_score).abs < 10**-11
  }
}

bismark = Bismark.new

b_g = bismark.root.add_element("group", {"name" => "mapping of #{ARGV[0]} on #{ARGV[1]} (flank_length=#{flank_length})", "size" => segs.size})
segs.each { |seg|
  seg.to_bismark(b_g)
}

File.open(out_bismark, "w") { |f| f << bismark.getXML }