#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"
require "#{File.dirname(File.expand_path(__FILE__))}/pmento.rb"

report "pmsit.rb started, usage <pwm_bismark> <seq_bismark> <genome_release> <flank_length> <out_bismark> [<mode>=2PWM|2SEQ] [<additional_id>=PMSIT]"
start __FILE__
exit(2) if ARGV.size < 5

pwm_bismark, seq_bismark = Bismark.new(ARGV[0]), Bismark.new(ARGV[1])
genome_release, flank_length = ARGV[2], ARGV[3].to_i
out_bismark = ARGV[4]
add_id = ARGV[5] ? ARGV[5] : "PMSIT"

motif_name = pwm_bismark.elements["//motif"].attributes["name"]
pm = PM.from_bismark(pwm_bismark.elements["//PWM"])

segs = []
seq_bismark.elements.each("//segment") { |e|
  segs << seg = Segment.from_bismark(e)
  seg.strand = Ytilib::STRAND_DIRECT
  seg.location -= flank_length
  seg.length += 2*flank_length
  seg.sequence = Seqripper.seqplace(genome_release, seg).upcase
}

outsites = []
segs.each { |seg|
  s = seg.sequence.dup
  seg.sequence.downcase!
  
  max_score = (0..(s.size - pm.size)).collect { |i|
    seq, seq_rc = s[i, pm.size], s[i, pm.size].revcomp!
    [pm.score(seq), pm.score(seq_rc)].max
  }.max
  
  (0..(s.size - pm.size)).each { |i|
    seq, seq_rc = s[i, pm.size], s[i, pm.size].revcomp!
    scor, scor_rc = pm.score(seq), pm.score(seq_rc)
    if ([scor, scor_rc].max - max_score).abs < 10**-11
      site = seg.dup
      site.location += i
      site.length = pm.size
      site.strand = scor >= scor_rc ? Ytilib::STRAND_DIRECT : Ytilib::STRAND_REVCOMP
      site.sequence = scor >= scor_rc ? seq : seq_rc
      outsites << site
    end
  }
}

bismark = Bismark.new

b_g = bismark.root.add_element("group", {"name" => "best hits of #{ARGV[0]} on #{ARGV[1]} (flank_length=#{flank_length})", "size" => segs.size})
outsites.each_with_index { |seg, i|
  bseg = seg.to_bismark(b_g)
  bseg.attributes["type"] = "site"
  bseg.attributes["id"] = "#{add_id}.#{bseg.attributes['id']}.#{i}"
}

File.open(out_bismark, "w") { |f| f << bismark.getXML }