#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"
require "#{File.dirname(File.expand_path(__FILE__))}/pmento.rb"
require "ftools"

report "bifoocut.rb <sequence_count> <motif_template> <min_motif_length> <max_motif_length> [mode=icd|nog|xi2] [<significance>=0.05]"
report "icd = discrete info.co.d. mode; nog = discrete info.co.d. no gaps mode; xi2 = chi-square criterion mode"
start __FILE__

exit(2) if ARGV.size < 4
sequence_count, motif_template, min_motif_length, max_motif_length, mode, significance = ARGV.shift, ARGV.shift, ARGV.shift.to_i, ARGV.shift.to_i, ARGV.last ? ARGV.shift : :icd, ARGV.last ? ARGV.shift.to_f : 0.05

Rekeeper.keepp("SIGNIFICANCE_LEVEL", significance, "chi-square criterion significance level") if mode == :xi2

sequence_count = sequence_count.to_i

srand

pms = (min_motif_length..max_motif_length).collect { |l|
  PM.from_bismark(Bismark.new("#{motif_template}#{l}.xml").elements["//PPM"]).get_pcm(sequence_count)
}

good_pms = []
mode = mode == :icd ? :icd : mode.intern
Rekeeper.keepp("MODE", mode, "length detection mode")

if mode == :xi2
  chi2thresh = Statistics2.pchi2_x(3, significance)
  pms.each { |pm|
    
    xi2 = pm.xi2(Randoom::DEF_PROBS)
    good_pms << pm unless xi2.first < chi2thresh || xi2.last < chi2thresh
    
  }
else
  
  i2, thc, tlc = pms[0].icd2of4, pms[0].icdThc, pms[0].icdTlc
  report "info.co.d 2 of 4 #{i2}"
  report "threshold H.C.   #{thc}"
  report "threshold L.C.   #{tlc}"
  
  pms.each { |pm|
    icd = pm.infocod
    good_pms << pm unless icd.first < tlc || icd.last < tlc
  }
  
  good_pms = good_pms.select { |pm|
    icd = pm.infocod
    icdl = (0...icd.size).inject("") { |s,i|
      if icd[i] >= thc
        l = "B"
      elsif icd[i] >= tlc
        l = "s"
      else
        l = "N"
      end
      s += l
    }
    
    nogaps = icdl.split('N').select { |s| !s.empty? }.select { |s| s !~ /[B]/ }.empty?
    report "motif with gap: #{icdl}" unless nogaps
    nogaps
    
  } if mode == :nog
  
end

motif = good_pms.last
report "motif length found is #{motif.size} (motif consensus #{motif.consensus})"
Rekeeper.keepp("MOTIF_LENGTH", motif.size, "motif length found")