#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"

def best_scores(pm, seqs)
  seqs = seqs.select { |s| s.size >= pm.size }
  best_scores = seqs.collect { |s|
  	
    max_score = (0..(s.size - pm.size)).collect { |i|
      seq, seq_rc = s[i, pm.size], s[i, pm.size].revcomp!
      [pm.score(seq), pm.score(seq_rc)].max
    }.max
  }
  
  #best_scores.compact!
  best_scores.sort!
  
  # p best_scores
  return best_scores
end

report "WARNING: only PWM is supported for now (so, there is NO IUPAC support for sequences)"
report "pmcmp.rb started, usage: <output_file> <input_sequences> <genome_release> <flank_length> <strict_flank>=no|yes <max_count_percent> <background_ACGT>=default|0.25,0.25,0.25,0.25 <mode>=PWM|words_count|0 <bismark_motif_1>..<bismark_motif_n>"
start __FILE__
report "WARNING: all motifs must have different file names"

exit(2) if ARGV.size < 9
output_file, sequences, genome_release, flank_length, strict_flank, max_count_percent, background, mode = ARGV.shift, ARGV.shift, ARGV.shift, ARGV.shift.to_i, ARGV.shift, ARGV.shift.to_f, ARGV.shift, ARGV.shift
background = background != "default" ? background.split(",").collect { |av| av.to_f } : [0.25, 0.25, 0.25, 0.25]
background = {'A' => background[0], 'C' => background[1], 'G' => background[2], 'T' => background[3]}
mode = mode.to_i unless mode == "PWM"
strict_flank = strict_flank && (strict_flank != "no" && strict_flank != "false")

# 1. Gathering motif names
motifs = ARGV.collect { |bismark_file|
  bismark_name = Bismark.new(bismark_file).elements["//motif"].attributes["name"]
  { :bismark_name => bismark_name,
    :name => bismark_file + '/' + bismark_name,
    :pm => mode == "PWM" ? PM.from_bismark(Bismark.new(bismark_file).elements["//PWM"]) : PM.from_bismark(Bismark.new(bismark_file).elements["//PPM"], true).get_pwm(mode, background),
    :bismark => bismark_file,
    :pat => File.name_wo_ext(bismark_file) + ".pat",
    :p_value_fn => File.name_wo_ext(bismark_file) + ".p_value",
   }
}

max_motif_length = motifs.collect { |m| m[:pm].length }.max
min_motif_length = motifs.collect { |m| m[:pm].length }.min

report "max_motif_length=#{max_motif_length}, min_motif_length=#{min_motif_length}"

# 1.0. Making additional flanks
unless strict_flank
  if File.ext_wo_name(sequences) == "xml"
    min_sequence_length = XPath.match(Bismark.new(sequences), path="//segment").collect { |e| e.attribute("length").value.to_i }.min
  else
    min_sequence_length = Ytilib.read_mfa2array(sequences).size
  end
  delta_l = max_motif_length - (min_sequence_length + 2*flank_length)
  flank_length = flank_length + ( delta_l > 0 ? delta_l : 0)
  report "using flank_length=#{flank_length}, minimum sequence length=#{min_sequence_length}"
end

# 1.1 Loading sequences & adding flanks || 1.2 Make motifs N compatible
segs = []
if File.ext_wo_name(sequences) == "xml"
  Bismark.new(sequences).elements.each("//segment") { |e|
    segs << seg = Segment.from_bismark(e)
    seg.location -= flank_length
    seg.length += 2*flank_length
    seg.sequence = Seqripper.seqplace(genome_release, seg).upcase
  }
  segs = segs.collect { |s| s.sequence }
else
  segs = Ytilib.read_mfa2array(sequences)
  segs = segs.collect { |s| "N"*flank_length + s + "N"*flank_length }
end

max_count_all = (segs.size * max_count_percent / 100.0).round

report "actual sequence count=#{segs.size}"
checkerr("found no segments in a given small-BiSMark file") { segs.empty? }

# 1. Setting sequence count limits
report "setting limits for motifs"
limits = {}
motifs.each { |m|
  limits[m[:name]] = segs.select { |s| s.size >= m[:pm].size }.size
}

# 2. Collecting thresholds for all matrices
motifs.each { |m|  
  m[:scores] = scores = best_scores(m[:pm], segs)
  
  checkerr("found empty scores list for motif #{m[:name]}, please check flank length settings") { scores.empty? }
  
  m[:thresholds] = threshs = []
  
  (1...scores.size).each { |i|
    next if scores[i-1] == scores[i]

    #middle thresholds - previous idea
    #threshs << { :count => segs.size - scores.rindex(scores[i-1]) - 1, :threshold => (scores[i] + scores[i-1]) / 2 }
    #threshs << { :count => segs.size - i, :threshold => (scores[i] + scores[i-1]) / 2 }
    
    threshs << { :count => segs.size - scores.rindex(scores[i-1]) - 1, :threshold => scores[i] }
    
  }
  
  threshs.delete_if { |t| t[:threshold] <= -Float::MAX }
  
  max_count = [segs.size - 1, limits[m[:name]], max_count_all].min
  if threshs.size == 0
    report "all best words have equal scores, choosing additional threshold"
    threshs << { :count => max_count, :threshold => scores.first } if scores.first > -Float::MAX
  elsif threshs[0][:count] < max_count
    report "best words for last sequences have equal scores, choosing additonal threshold"
    threshs.insert(0, { :count => max_count, :threshold => scores[0] } ) if scores[0] > -Float::MAX
  end
  
  # sorting thresholds to go in decreasing order (so we can stop at some concrete point)
  threshs.reverse!
}
average_length = segs.inject(0) { |sum, s| sum += s.length } / segs.size

# 3. Creating p_value data files
motifs.each { |m|
  threshs = m[:thresholds]
  report "collecting P-values for motif #{m[:name]}, will count #{threshs.size} entries"
  
  pvs = []
  threshs.each_with_index { |t,i|
    
    next if t[:count] > max_count_all
    
    p_value = Extlz.p_value(m[:pm], t[:threshold], average_length, complement=true, background)
    
    unless p_value
      report "broken P-value calculation, may be there is no enough memory (too long motif)"
      break
    end
   
    pvs << {:count => t[:count], :p_value => p_value}
    if i > 0 && t[:count] - threshs[i-1][:count] > 1
      # let's fill all 'middle' thresholds - for sequences with equal scores for 'best' sites
      ((threshs[i-1][:count]+1)...t[:count]).each { |j|
        pvs << {:count => j, :p_value => p_value}
      }
    elsif i == 0 && t[:count] > 1
      (1...t[:count]).each { |j| pvs << {:count => j, :p_value => p_value} }
    end
    
  }
  
  pvs = pvs.sort { |a,b| a[:count] <=> b[:count] }
  
  File.open(m[:p_value_fn], "w") { |f_pv|
    pvs.each { |pv| f_pv.puts("#{pv[:count]} #{pv[:p_value]}") }
  }
}

Rekeeper.keepp("FLANK_LENGTH", flank_length, "sequence flank length")

output_file = File.name_wo_ext(output_file)
File.open(output_file + ".plot", "w") { |plot_f|
  plot_f.puts "set terminal png small font #{Ytilib::FONT_GDDEFAULT} 9 size 640, 480"
  plot_f.puts "set title 'PWM ROC curves based on #{sequences} (used #{max_count_all} of #{segs.size}), average length=#{average_length} (flank length=#{flank_length})'"
  plot_f.puts "set key left"
  plot_f.puts "set grid"
  plot_f.puts "set logscale x"
  plot_f.puts "set format x '%g'"
  plot_f.puts "set ytics 1"
  plot_f.puts 'set ylabel "number of sequences,\n containing at least one site scoring above the threshold"'
  plot_f.puts "set xlabel 'P-value'"
  plot_f.puts "set y2tics ('50%%' #{(segs.size/100.0 * 50).to_i}, '90%%' #{(segs.size/100.0 * 90).to_i})"
  plot_f.puts 'set y2label "percentage of sequences,\n containing at least one site scoring above the threshold"'
  plot_f.puts "set output '#{output_file}.png'"
  plot_f << "plot "
  motifs.each_with_index { |m,i|
    plot_f << "'#{m[:p_value_fn]}' using 2:1 with lines t '#{m[:name]}'"
    plot_f << "," if i < motifs.size-1
  }
  plot_f.puts
}

`#{Ytilib::PATH_GNUPLOT} #{output_file + ".plot"}`

Rekeeper.keepp("TOTAL_COUNT", segs.size, "total number of sequences from set")
Rekeeper.keepp("USED_COUNT", max_count_all, "number of used (best) sequences for each motif")
Rekeeper.keepr("SELECTIVITY_GRAPH", "#{output_file}.png", "P-value for matrices using different thresholds on initial sequence set")