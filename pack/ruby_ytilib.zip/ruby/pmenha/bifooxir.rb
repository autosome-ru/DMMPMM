$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"

$program_path = File.dirname(File.expand_path(__FILE__))

start_significance = 0.01
report "bifooxir.rb <signi_high>=0.01|0 <signi_low>=0.05|0 <signi_delta>=0.005|0 <bifooxi_param_list_(w/o_significance)>"
start __FILE__

exit(2) if ARGV.size < 3
signi_high, signi_low, signi_delta = ARGV.shift, ARGV.shift, ARGV.shift
params = ARGV.inject("") { |params, argv| params += "#{argv} " }

signi_high = signi_high == '0' ? 0.01 : signi_high.to_f
signi_low = signi_low == '0' ? 0.05 : signi_low.to_f
signi_delta = signi_delta == '0' ? 0.005 : signi_delta.to_f

Rekeeper.keepp("SIGNIFICANCE_HIGH", signi_high, "chi-square criterion significance upper border")
Rekeeper.keepp("SIGNIFICANCE_LOW", signi_low, "chi-square criterion significance lower border")
Rekeeper.keepp("SIGNIFICANCE_DELTA", signi_delta, "chi-square criterion significance delta")

motif_length, signi = 0, signi_low
while signi - signi_high >= 0
  report "checking significance value=#{signi}"
  res = `ruby #{$program_path}/bifooxi.rb #{params} #{signi}`
  res = res.split("\n").last
  puts res
  
  signi -= signi_delta
  
  parex = Rereader.new
  motif_length = [parex.get("bifooxi", "MOTIF_LENGTH")[:value], motif_length].max
end

report "got motif length=#{motif_length}"
Rekeeper.keepp("MOTIF_LENGTH", motif_length, "motif length identified by bifooxi tool")