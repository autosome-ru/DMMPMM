#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"
require "#{File.dirname(File.expand_path(__FILE__))}/pmento.rb"

def profile(pm, s)
  profile = []
  (0..(s.size - pm.size)).each { |i|
    seq, seq_rc = s[i, pm.size], s[i, pm.size].revcomp!
    score, score_rc = pm.score(seq), pm.score(seq_rc)
    if score > score_rc
      profile << {:seq => seq, :score => score, :loc => i }
    else
      profile << {:seq => seq_rc, :score => score_rc, :loc => i }
    end
  }
  profile.sort! { |a,b| b[:score] <=> a[:score] }
  return profile
end

def get_pack(segments, pm)
  pack = []
  segments.each { |s|
    prof = profile(pm, s.seq)
    
    pack << prof.shift
    
    pack.last[:loc] += s.loc
    pack.last[:chr] = s.chr
    pack.last[:seg] = s
    pack.last[:size] = pm.size
  }
  pack.sort! { |a,b| b[:score] <=> a[:score] }
 
  return pack
end

report "flkscn3.rb started, usage <pwm_bismark> <seq_bismark> <genome_release> [<MC_times>=1048576]"
start __FILE__
exit(2) if ARGV.size < 3

pwm_bismark, pwm_bismark_f_n = Bismark.new(ARGV[0]), ARGV[0]
seq_bismark_f_n = ARGV[1]
seq_bismark = Bismark.new(seq_bismark_f_n)
genome_release = ARGV[2]
mc_times = ARGV[3] ? ARGV[3].to_i : 1048576

seqs = []
seq_bismark.elements.each("//segment") { |e|
  seqs << Segment.from_bismark(e)
}

pm = PM.from_bismark(pwm_bismark.elements["//PWM"])
flank_length = pm.size

motif_name = pwm_bismark.elements["//motif"].attributes["name"]
report "adjusting starting sequences to allow at least 1 motif entry in each"

seqs.each { |s|
  if pm.size > s.length
    sfl_length = ((pm.size - s.length) / 2.0).ceil
    s.location -= sfl_length
    s.length += 2*sfl_length
    s.sequence = Seqripper.seqplace(genome_release, s).upcase
  end
}

starting_pack = get_pack(seqs, pm)

# 0. calculating matrix properties
pm_sigma, pm_avg_score = 0, 0
pm.score_sigma(mc_times) { |sigma_res, avg_score_res|
  pm_sigma = sigma_res
  pm_avg_score = avg_score_res
}
Rekeeper.keepp("MONTECARLO_COUNT", mc_times, "number of montecarlo iterated words for PWMs longer than 10")

threshold_low = pm_avg_score + pm_sigma
threshold_high = pm_avg_score + 2*pm_sigma
report "matrix parameters below"
report "average score=#{pm_avg_score}, best score=#{pm.best_score}, worst score=#{pm.worst_score}"

# 1. extracting sequences without sites
report "using site absence (mean+sigma) threshold=#{threshold_low}, appearance (mean+2sigma) threshold=#{threshold_high}"

seg_wi_sites = []
seg_wo_sites = []
starting_pack.dup.each { |sp|
  seg_wi_sites << sp if sp[:score] >= threshold_low
  seg_wo_sites << sp if sp[:score] < threshold_low
}
report "total sequence count=#{starting_pack.size}"
report "sequences without site presence, count=#{seg_wo_sites.size}"

threshold_strict = pm_avg_score + 3*pm_sigma
report "using strict site presence (mean+3sigma) threshold=#{threshold_strict}"
strict_sites_count = starting_pack.select { |sp| sp[:score] >= threshold_strict }.size
report "sequences without strict site presence, count=#{starting_pack.size-strict_sites_count}"
report "worst score in the set=#{starting_pack.last[:score]}"
report "best score in the set=#{starting_pack[0][:score]}"

seg_wi_sites.sort! { |a,b| a[:loc] <=> b[:loc] }

sws_w_chr = {}
seg_wi_sites.each { |spp|
  sws_w_chr[spp[:chr]] = [] unless sws_w_chr[spp[:chr]]
  sws_w_chr[spp[:chr]] << spp
}

# 2. here we have - seg_wo_sites - best hits from segments not having site, 
# sws_w_chr - segments sorted by chromosome, having good site occurence within

def no_cross(sws, prf, flank_length)
  return true unless sws
  # p_o - sequence without site, p_c - new good site, s - some sequence with site
  p_o_left = prf[:seg].loc
  p_o_right = prf[:seg].loc + prf[:seg].len - 1
  p_c_left = p_o_left - flank_length + prf[:loc]
  p_c_right = p_c_left + prf[:size] - 1
  
  sws.each { |s|
    s_left = s[:seg].loc
    s_right = s[:seg].location + s[:seg].length - 1
    
    if s_left < p_o_left
      # composition is <foot_w_size> <new_site> <foot_wo_site>
      return false unless p_c_left > s_right
    else
      return false unless p_c_right < s_left
    end
  }
  true
end

exit if seg_wo_sites.size == 0
[flank_length, 2].each { |flank_length|
  appeared_sites, no_appeared_sites_scores, appeared_sites_scores = [], [], []
  seg_wo_sites.each { |swos|
    new_swos = swos[:seg].dup
    new_swos.location -= flank_length
    new_swos.length += 2*flank_length
    new_swos.sequence = Seqripper.seqplace(genome_release, new_swos).upcase
    prof = profile(pm, new_swos.seq)
    
    prof_part = nil
    prof.each { |prf|
      prf[:seg] = swos[:seg]
      prf[:size] = pm.size
      if no_cross(sws_w_chr[swos[:chr]], prf, flank_length)
        prof_part = prf
        break
      #else
      #  report "new site overlapped with other sequence, skipping"
      end
    }
    
    best_new_score = prof_part ? prof_part[:score] : -Float::MAX
    
    if best_new_score > threshold_high
      appeared_sites << prof_part
      appeared_sites_scores << prof_part[:score]
    else
      no_appeared_sites_scores << best_new_score
    end
  }

  report "used flank length=#{flank_length}, sequences with appeared sites count=#{appeared_sites.size}"
}