#!/usr/bin/ruby

require 'benchmark.rb'

class Bigfoot
  
  def Bigfoot.get_local_segments(segs, flank_length, motif_length)
    checkerr("cannot consider global segment as local") { segs[0].chromosome }
    
    seqs = segs.collect { |s| 
      s1 = s.dup
      s1.sequence.upcase!
      s1.length += 2 * flank_length
      s1.sequence = "N"*flank_length + s1.sequence + "N"*flank_length
      s1.weight = 1
      checkerr("too short local segment") { s1.length < motif_length }
      s1
    }
    
    return seqs
  end
  
  def initialize(bismark_input, flank_length, genome_release, refine_steps, motif_length, extended_mode = nil, acgt_mode = nil, rounding_mode = :float)
    checkerr("in this version rounding mode can be float only") { rounding_mode != :float }
    @bigfoot_path = File.dirname(File.expand_path(__FILE__))
    
    segs = []
    Bismark.new(bismark_input).elements.each("//segment") { |e|
      segs << Segment.from_bismark(e)
    }
    
    @total_weight = segs.size
    @flank_length = flank_length
    @genome_release = genome_release 
    @refine_steps = refine_steps
    @extended_mode = extended_mode ? :llib : nil
    @acgt_mode = acgt_mode ? :llib : nil
    if segs[0].chromosome
      # @segs = get_flanked_segments(segs, flank_length, genome_release, motif_length)
      # deprecated, can give unstable motifs
      @segs = segs.collect { |s|
      	s = s.dup
      	s.location -= flank_length
      	s.length += 2 * flank_length
      	s.sequence = Seqripper.seqplace(genome_release, s).upcase
      	s.weight = 1
      	s
      }
    else
      @segs = Bigfoot.get_local_segments(segs, flank_length, motif_length)
    end
    
    @result = []
    @motif_length = motif_length
    
    @rounding_mode = rounding_mode
    report "using rounding mode=#{@rounding_mode} for weighted PCM building" if @rounding_mode
    report "using floating point mode for weighted PCM building; it can be :round, :floor" unless @rounding_mode
  end

  def f_bd(s)
    di = []
    (0..s.size-@motif_length).each { |i|
      di << s[i, @motif_length] << s[i, @motif_length].revcomp
    }
    di.sort!
    di.uniq!
    di
  end
  
  def delta(s1, s2)
    delt = 0
    (0...s1.size).each { |i|
      delt += s1[i] == s2[i] ? 0 : 1
    }
    delt
  end
  
  def foot
  
    report "preprocessing dictionaries"
    all_pairs = {}
    
    (0..@motif_length).each { |i|
      all_pairs[i] = {}
    }
    
    seqs = @segs.collect { |s| s.sequence }
    
    di = []
    seqs.each_with_index { |s,i| di[i] = f_bd(s) }
    
    pairs = {}
    di.each_with_index { |di1, i|
      di.each_with_index { |di2, j|
        next if i == j
        
        di1.each { |w1|
          di2.each { |w2|
            real_delta = delta(w1, w2)
            pairs = all_pairs[real_delta]
            next unless pairs
            key1, key2, key3, key4 = w1+w2, (w1+w2).revcomp, w2+w1, (w2+w1).revcomp
            pairs[key1] = pairs[key2] = pairs[key3] = pairs[key4] = [w1, w2] unless pairs[key1]
          }
        }
      }
    }
    
    all_pairs.each_key { |to_check|
      all_pairs[to_check] = all_pairs[to_check].values.uniq
    }

    @sequences_file = Extlz.temp_str("sequences.llib")
    File.open(@sequences_file, "w") { |f| @segs.each { |s| f.puts(s.seq) } }
    
    best = []
    (0..@motif_length).each { |i|
      report "processing word-delta=#{i}"
      next unless all_pairs[i]
      next if all_pairs[i].empty?
      best << footstep(all_pairs[i])
      unless best.last
        report "probable system error, exiting"
        exit(2)
      end
      best.last[:delta] = i
      best.sort! { |a,b| b[:total_infocod] <=> a[:total_infocod] }
      report "overall info.co.d. leader #{best.first[:total_infocod]} on delta #{best.first[:delta]} (motif length=#{@motif_length})"
    }
    
    File.delete(@sequences_file)
    
    best.sort! { |a,b| b[:total_infocod] <=> a[:total_infocod] } 
    
    Rekeeper.keepp("LEADER_DELTA", best.first[:delta], "delta for word-pair corresponding to matrix with the best final discrete information content")
    Rekeeper.keepp("LEADER_PHASE", best.first[:phase], "<Footstep> search phase corresponding to matrix with the best final discrete information content")
    
    return best.first
  end
  
  def footstep(word_pair)
    report "will check #{word_pair.size} different word pairs"
    
    #benchmarking won't work in IUPAC cases
    if @acgt_mode
      report "testing old-engine performance"
      minutes = Benchmark.measure { optimize(PM.new_pcm(word_pair.first)) }.real / 60.0
      report "INFO: this round could take up to #{(word_pair.size * minutes).round_to(1)} minutes using old engine"
    end
    
    pair, pm, phase = nil, nil, nil
    best_infocod = Extlz.make_temp("word_pair.llib") { |word_pair_fn|
      File.open(word_pair_fn, "w") { |f| word_pair.each { |wp| f.puts("#{wp[0]} #{wp[1]}") } }
      
      report "running footstep-engine: java -Xms268435456 -Xmx1073741824 -cp \"#{Ytilib::PATH_EXTLZ}dnanimals\" Footstep #{@sequences_file} #{@segs.size} #{word_pair_fn} #{@extended_mode} #{@acgt_mode}"
      res = nil
      minutes = Benchmark.measure { res = `java -Xms268435456 -Xmx1073741824 -cp \"#{Ytilib::PATH_EXTLZ}dnanimals\" Footstep #{@sequences_file} #{@segs.size} #{word_pair_fn} #{@extended_mode} #{@acgt_mode}` }.real / 60.0
      report "INFO: using <Footstep> engine it took #{minutes.round_to(1)} minutes"
      
      return nil unless res.include?("success")
      
      res.each_line { |l| report "<Footstep> #{l}" }
      res = res.split("\n")[-8..-1].collect { |s| s.strip }
      report "best info.co.d. on current step is #{res[0]}"
      phase = res[1]
      pair = [res[2], res[3]]
      a_counts = res[4].split[1..-1].collect { |c| c.to_f }
      c_counts = res[5].split[1..-1].collect { |c| c.to_f }
      g_counts = res[6].split[1..-1].collect { |c| c.to_f }
      t_counts = res[7].split[1..-1].collect { |c| c.to_f }
      
      pm = PM.new(@motif_length, {'A' => a_counts, 'C' => c_counts, 'G' => g_counts, 'T' => t_counts }, @segs.size)
      res[0].to_f
    }
    report "finalizing step, optimizing matrix using old engine"
    optimized_result = optimize(pm.dup.iupacomp!)
    checkerr("too small refine steps count") { !optimized_result }
    report "info.co.d. found by old engine: #{optimized_result[:total_infocod]}"
    optimized_result[:pair] = pair
    optimized_result[:phase] = phase.to_i
    # optimized_result[:total_infocod] = best_infocod
    # optimized_result[:pm] = pm
    
    return optimized_result
  end
    
private

  def optimize(pm)
    
    @tick_count = 0
    
    oresults = {-Float::MAX => {:total_infocod => -Float::MAX, :pm => :llib, :alignment => :llib}}
    
    while @tick_count < @refine_steps
      
      alignment = get_weighted_alignment(@segs, pm.get_pwm(@segs.size, Randoom::DEF_PROBS, @segs.size))
      
      pm = PM.weighted_pcm(alignment, @rounding_mode)
      
      new_total_infocod = pm.infocod.inject(0) { |infc, e| infc += e }
            
      report "processed refine steps=#{@tick_count}, info.co.d.=#{new_total_infocod}"
      
      return oresults[new_total_infocod] if oresults[new_total_infocod]
      
      oresults[new_total_infocod] = {:total_infocod => new_total_infocod, :pm => pm, :alignment => alignment}
      
      @tick_count += 1
      
    end
    
    return nil
  end
 
end