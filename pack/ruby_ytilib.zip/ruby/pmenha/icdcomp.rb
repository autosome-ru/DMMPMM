#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"
require "#{File.dirname(File.expand_path(__FILE__))}/pmento.rb"

report "icdcomp.rb started, usage <sequence_count> <ppm_bismark_template>|<ppm_bismark1>..<ppm_bismarkN>"
start __FILE__
exit(2) if ARGV.size < 2

sequence_count = ARGV.shift.to_i
if ARGV.size > 1
  pms = ARGV.collect { |f_n| PM.from_bismark(Bismark.new(f_n).elements["//PPM"]) }
  names = ARGV.collect { |f_n| f_n }
elsif File.ext_wo_name(ARGV[0]) == "xml"
  pms = [PM.from_bismark(Bismark.new(ARGV[0]).elements["//PPM"])]
  names = [ARGV[0]]
else
  pms, names = [], []
  (6..17*17).each { |i|
    f_n = "#{ARGV[0]}_#{i}.xml"
    break unless (pms.empty? || File.exist?(f_n))
    next unless File.exist?(f_n)
    pms << PM.from_bismark(Bismark.new(f_n).elements["//PPM"])
    names << f_n
  }
end

names.each_with_index { |name, i|
  pms[i].words_count = sequence_count
  icdt = pms[i].infocod.inject(0) { |sum, icd| sum += icd }
  icd = pms[i].infocod
  scores = []
  Bismark.new(name).elements.each("//word") { |word|
    scores << word.attribute("score").value.to_f
  }
  
  var_icd = icd.variance
  
  report "matrix #{name} has info.co.d=#{icdt}, info.co.d.variance=#{var_icd}"
}