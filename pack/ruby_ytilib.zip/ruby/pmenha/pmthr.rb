#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"
require "#{File.dirname(File.expand_path(__FILE__))}/pmento.rb"

report "pmthr.rb started, usage <pwm_bismark> <out_bismark> [<pseudocount>=1] [background=0.25,0.25,0.25,0.25] [threshold_estimation=yes|no]"
start __FILE__
exit(2) if ARGV.size < 2

ppm_bismark = Bismark.new(ARGV[0])
seqs = []
pseudocount = ARGV[2] ? ARGV[2].to_i : 1
background = ARGV[3] ? ARGV[3].split(",").collect { |av| av.to_f } : [0.25, 0.25, 0.25, 0.25]
background = {'A' => background[0], 'C' => background[1], 'G' => background[2], 'T' => background[3]}
threshold_estimation = !ARGV[4] || ARGV[4] == "yes" || ARGV[4] == "true"

pm = ARGV[3] ? PM.from_bismark(ppm_bismark.elements["//PPM"]) : PM.from_bismark(ppm_bismark.elements["//PWM"])
if ARGV[3]
  pm = pm.get_pwm(nil, background, pseudocount)
  ppm_bismark.elements.delete_all("//PWM")
  pm.to_bismark(ppm_bismark.elements["//motif"])
  
  if wl=ppm_bismark.elements["//word-list"]
    words = []
    wl.elements.each("//word") { |w| words << w.text }
    ppm_bismark.elements.delete_all("//word-list")
    
    bm = ppm_bismark.elements["//motif"]
    wl = bm.add_element("word-list", {"size" => words.size})
    words.each { |word|
      wl.add_element("word", {"score" => pm.score(word)}).add_text(word)
    }
  end

end
report "using motif size=#{pm.size}"

mc_times = 1048576
Rekeeper.keepp("MONTECARLO_COUNT", mc_times, "number of montecarlo iterated words for PWMs longer than 10")

if threshold_estimation
  report "estimating threshold..."

  pm_sigma, pm_avg_score = 0, 0
  pm.score_sigma(mc_times) { |sigma_res, avg_score_res|
    pm_sigma = sigma_res
    pm_avg_score = avg_score_res
  }

  threshold = pm_avg_score + 3 * pm_sigma

  ppm_bismark.elements["//PWM"].attributes["threshold"] = threshold.to_s
end

File.open(ARGV[1], "w") { |f| f << ppm_bismark.getXML }