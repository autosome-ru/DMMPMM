#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"
require "#{File.dirname(File.expand_path(__FILE__))}/pmento.rb"

report "pmflank.rb started, usage <ppm_bismark> <seq_bismark> <genome_release> <sequence_flank_length> <matrix_flank_length> <out_bismark> [<background_ACGT>=0.25,0.25,0.25,0.25] [<significance>=0.05]"
start __FILE__
exit(2) if ARGV.size < 6
report "proceeding..."

ppm_bismark, seq_bismark = Bismark.new(ARGV[0]), Bismark.new(ARGV[1])
genome_release, seq_flank_length = ARGV[2], ARGV[3].to_i
matrix_flank_length, out_bismark = ARGV[4].to_i, ARGV[5]
background = ARGV[6] ? ARGV[6].split(",").collect { |av| av.to_f } : [0.25, 0.25, 0.25, 0.25]
background = {'A' => background[0], 'C' => background[1], 'G' => background[2], 'T' => background[3]}
significance = ARGV[7] ? ARGV[7].to_f : 0.05
Rekeeper.keepp("SIGNIFICANCE_LEVEL", significance, "chi-square criterion significance level")
significance = Statistics2.pchi2_x(3, significance)

motif_name = ppm_bismark.elements["//motif"].attributes["name"]
pm = PM.from_bismark(ppm_bismark.elements["//PPM"])
report "using initial motif size=#{pm.size}"

segs = []
seq_bismark.elements.each("//segment") { |e|
  segs << (s = Segment.from_bismark(e))
  s.location -= seq_flank_length
  s.length += 2 * seq_flank_length
  checkerr("found too short sequence length #{s.length}") { s.length < pm.size }
  s.sequence = Seqripper.seqplace(genome_release, s).upcase
}

class Segment
  def find_occs(pm)
    occs = (0..sequence.size-pm.size).collect { |i|
      word = sequence[i, pm.size]
      [{:strand => Ytilib::STRAND_DIRECT, :score => pm.score(word), :index => i, :word => word}, 
      {:strand => Ytilib::STRAND_REVCOMP, :score => pm.score(word.revcomp), :index => i, :word => word.revcomp}]
    }.flatten
    maxscore = occs.collect { |oc| oc[:score] }.max
    @best_occs = occs.select { |oc| oc[:score] == maxscore }
    @best_occs.each { |oc| oc[:weight] = 1.0 / @best_occs.size }
  end
  
  def proceed_occs(flank_length, genome_release)
    pmoccs = @best_occs.collect { |oc|
      realoci = oc[:index] + location - flank_length
      realocilength = oc[:word].size + 2*flank_length
      newsplac = Segment.new(self.chrom, realoci, realocilength, oc[:strand])
      
      # DEBUG
      # p "#{oc[:weight]} #{oc[:word]} #{oc[:score]}"
      {:seq => Seqripper.seqplace(genome_release, newsplac).upcase, :weight => oc[:weight]}
    }
  end
end

pm = pm.get_pwm(segs.size, Randoom::DEF_PROBS, segs.size)
# building alignment within fixed regions
newwords = segs.collect { |s|
  s.find_occs(pm)
  s.proceed_occs(matrix_flank_length, genome_release)
}.flatten

pm = PM.weighted_pcm(newwords)
class PM
  attr_accessor :size
end

xi2 = pm.xi2(background)

# DEBUG
# p xi2

#left flank
lcoli = matrix_flank_length
(matrix_flank_length-1).downto(0) { |i|
  break if xi2[i] < significance
  lcoli = i
}

#right flank
rcoli = pm.size - matrix_flank_length - 1
(pm.size - matrix_flank_length).upto(pm.size - 1) { |i|
  break if xi2[i] < significance
  rcoli = i
}

pm.size = rcoli - lcoli + 1
['A','C','G','T'].each { |l| pm.matrix[l] = pm.matrix[l][lcoli..rcoli] }
newwords.each { |ww| ww[:seq] = ww[:seq][lcoli..rcoli] }

report "found motif length #{pm.size}"
Rekeeper.keepp("MOTIF_LENGTH", pm.size, "motif length found")
Rekeeper.keepp("FLANK_LENGTH", seq_flank_length, "sequence flank length used")

save_bismark(pm, newwords, out_bismark, motif_name)

system("ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo.rb #{out_bismark} #{out_bismark}.png #{segs.size}")