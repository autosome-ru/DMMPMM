module Ytilib
  class Segment
    attr_accessor :weight
  end
  
  class PM
    
    def xi2_column(column, probs = Randoom::DEF_PROBS)
      checkerr("words count is undefined") { !words_count }
      ['A','C','G','T'].inject(0) { |sum, l|
        sum += ( ( @matrix[l][column] - @words_count*probs[l] )**2 / (@words_count * probs[l]) )
      }
    end
    
    def xi2(probs = Randoom::DEF_PROBS)
      (0...@size).collect { |pos| xi2_column(pos, probs) }
    end
    
    def PM.weighted_pcm(wa, mode = :float)
      size = wa[0][:seq].size
      counts = new_matrix(size)
      counts.each_value { |arr| arr.fill(0.0) }
      wa.each { |wae|
        weight, word = wae[:weight], wae[:seq]
        0.upto(size-1) { |i|
          letter = word[i,1].upcase
          unless ['A', 'C', 'G', 'T'].include?(letter)
            if letter == 'N'
              ['A', 'C', 'G', 'T'].each { |l17|
                counts[l17][i] += weight / 4
              }
            else
              checkerr("found unknown letter #{letter}")
            end
          else
            counts[letter][i] += weight
          end
        }
      }
      ['A','C','G','T'].each { |l| (0...size).each { |i| counts[l][i] = counts[l][i].floor } } if mode == :floor
      ['A','C','G','T'].each { |l| (0...size).each { |i| counts[l][i] = counts[l][i].round } } if mode == :round
      newpcm = PM.new(size, counts)
      newpcm.matrix['N'] = (0...size).collect { |i| ((m=newpcm.matrix)['A'][i] + m['C'][i] + m['G'][i] + m['T'][i]) / 4 }
      
      return newpcm
    end
    
  end
  
end

def cross_seg(segs, seg2, flank_len, verbose = false)
  seg1 = segs.pop
  if seg2.location - flank_len < (seg1.location + seg1.length + flank_len)
    # there is crossing
    report "joining two segments: #{seg1.location},#{seg1.length} vs #{seg2.location},#{seg2.length}" if verbose
    segs << Segment.new(seg1.chr, seg1.loc, [seg1.location + seg1.length, seg2.location + seg2.length].max - seg1.loc)
    segs.last.weight = seg1.weight + 1
  else
    segs << seg1 << seg2
  end
end

def get_flanked_segments(seqs, flank_length, genome_release, limit_size)
  
  seqs.sort! { |a, b| a.location <=> b.location }

  seqs_wchr = {}
  seqs.each { |s|
    seqs_wchr[s.chromosome] = [] unless seqs_wchr.has_key?(s.chromosome)
    seqs_wchr[s.chromosome] << s.dup
  }

  seqs_joined = []
  seqs_wchr.each_key { |chr|
    chr_s = seqs_wchr[chr]
    seqs_joined << chr_s.shift
    seqs_joined.last.weight = 1
    chr_s.each { |s|
      s.weight = 1
      cross_seg(seqs_joined, s, flank_length)
    }
  }

  report "initial sequences count=#{seqs.size}"
  report "joined sequences count=#{seqs_joined.size}, weight=#{seqs_joined.inject(0) {|sum, s| sum += s.weight} }"

  # adding flanks
  seqs_joined.dup.each { |s|
    s.location -= flank_length
    s.length += 2*flank_length
    seqs_joined.delete(s) if s.length < limit_size
    report "skipping sequence #{Seqripper.seqplace(genome_release, s)}" if s.length < limit_size
  }

  report "joined flanked sequences count=#{seqs_joined.size}, weight=#{seqs_joined.inject(0) {|sum, s| sum += s.weight} }"

  seqs_joined.each { |s|
    s.sequence = Seqripper.seqplace(genome_release, s).upcase
  }
  
  return seqs_joined
end

def profile(pm, s)
  profile = []
  (0..(s.size - pm.size)).each { |i|
    seq, seq_rc = s[i, pm.size], s[i, pm.size].revcomp!
    score, score_rc = pm.score(seq), pm.score(seq_rc)
    profile << {:seq => seq, :score => score}
    profile << {:seq => seq_rc, :score => score_rc}
  }
  profile.sort! { |a,b| b[:score] <=> a[:score] }
  
  return profile
end

def get_alignment(segments, pm)

  alignment = []
  segments.each { |s|
    prof = profile(pm, s.seq)
    s.weight.times { alignment << prof.shift }
  }
  alignment.sort! { |a,b| b[:score] <=> a[:score] }
 
  return alignment
end

def get_weighted_alignment(segments, pm)

  alignment = []
  segments.each { |s|
    prof = profile(pm, s.seq)
    
    to_alignment = []
    s.weight.times {
      to_alignment << prof.shift
    }
    
    while !prof.empty? && to_alignment.last[:score] == prof[0][:score]
      to_alignment << prof.shift
    end
    
    to_alignment.each { |toa|
      alignment << toa
      alignment.last[:weight] = s.weight.to_f / to_alignment.size
    }
    
  }
  
  # not necessary now
  # alignment.sort! { |a,b| b[:score] <=> a[:score] }

  return alignment
end

def get_sequence_alignment(seqs, pm)

  alignment = []
  seqs.each { |s|
    
    prof = profile(pm, s)
    
    to_alignment = []
    to_alignment << prof.shift
    
    while !prof.empty? && to_alignment.last[:score] == prof[0][:score]
      to_alignment << prof.shift
    end
    
    to_alignment.each { |toa|
      alignment << toa
      alignment.last[:weight] = 1.0 / to_alignment.size
      alignment.last[:from_seq] = s
    }
    
  }
  
  return alignment
end


def save_bismark(pm, alignment, out_bismark, motif_name, infocod=nil, threshold=nil, ready_pwm = nil )
  bismark = Bismark.new
  
  bismark.root.add_element("motif", {"id" => "#{motif_name.to_id}.MTF", "name" => "#{motif_name}"})
  
  if infocod
    bismark.elements["//motif"].add_element("comment", {"name" => "discrete information content by position"}).add_text(infocod.inspect.to_s)
    total_infocod = infocod.inject(0) { |ttl, icd| ttl += icd }
    bismark.elements["//motif"].add_element("comment", {"name" => "discrete information content"}).add_text(total_infocod.to_s)
  end
  
  bismark.elements["//motif"].add_element("comment", {"name" => "number of sequences in the corresponding alignment"}).add_text(pm.words_count.to_s) if pm.words_count
  
  pm.get_ppm.to_bismark(bismark.elements["//motif"])
  (pm = ready_pwm ? ready_pwm : pm.to_pwm!).to_bismark(bismark.elements["//motif"])
  bismark.elements["//PWM"].attributes["threshold"] = threshold.to_s if threshold
  
  bi_wl = bismark.elements["//motif"].add_element("word-list", {"size" => alignment.size})
  alignment.each { |ae|
    bi_wl.add_element("word", {"score" => pm.score(ae[:seq])}).add_text(ae[:seq])
  }
  
  File.open(out_bismark, "w") { |f| f << bismark.getXML }
end
