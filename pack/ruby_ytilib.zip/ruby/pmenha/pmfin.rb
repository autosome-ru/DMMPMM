#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"
require "#{File.dirname(File.expand_path(__FILE__))}/pmento.rb"

report "pmfin.rb started, usage <ppm_bismark> <out_bismark> <sequences> [<pseudocount>=1] [background=0.25,0.25,0.25,0.25] [<threshold>]"
report "small-BiSMark input should contain sequences"
start __FILE__
exit(2) if ARGV.size < 3

ppm_bismark = Bismark.new(ARGV[0])
seqs = []
pseudocount = ARGV[3] ? ARGV[3].to_i : 1
background = ARGV[4] ? ARGV[4].split(",").collect { |av| av.to_f } : [0.25, 0.25, 0.25, 0.25]
background = {'A' => background[0], 'C' => background[1], 'G' => background[2], 'T' => background[3]}
PPM.probs2IUPAC!(background)
threshold = ARGV[5] ? ARGV[5].to_f : nil

motif_name = ppm_bismark.elements["//motif"].attributes["name"]
pm = PM.from_bismark(ppm_bismark.elements["//PPM"], true)
report "using motif size=#{pm.size}"

report "loading sequences..."
if File.ext_wo_name(ARGV[2]) == "xml"
  Bismark.new(ARGV[2]).elements.each("//segment") { |e|
    seqs << Segment.from_bismark(e).sequence.upcase
    checkerr("found empty sequence") { !seqs.last }
    checkerr("found too short sequence") { seqs.last.size < pm.size }
  }
else
  seqs = Ytilib.read_seqs2array(ARGV[2])
  seqs.each { |s|
    checkerr("found too short sequence") { s.size < pm.size }
  }
end

Rekeeper.keepp("SEQUENCE_COUNT", seqs.size, "initial sequence count")

pm = pm.get_pwm(seqs.size, background, pseudocount)
alignment = get_sequence_alignment(seqs, pm)

mc_times = 1048576
Rekeeper.keepp("MONTECARLO_COUNT", mc_times, "number of montecarlo iterated words for PWMs longer than 10")

unless threshold
  report "estimating threshold..."

  pm_sigma, pm_avg_score = 0, 0
  pm.score_sigma(mc_times) { |sigma_res, avg_score_res|
    pm_sigma = sigma_res
    pm_avg_score = avg_score_res
  }

  threshold = pm_avg_score + 1 * pm_sigma
end

report "filtering alignment..."
alignment = alignment.select { |a1|
  a1[:score] >= threshold
}

pm = PM.weighted_pcm(alignment)

report "reestimating threshold..."

pwm = pm.get_pwm(seqs.size, background, pseudocount)
pm_sigma, pm_avg_score = 0, 0
pwm.score_sigma(mc_times) { |sigma_res, avg_score_res|
  pm_sigma = sigma_res
  pm_avg_score = avg_score_res
}

threshold = pm_avg_score + 3 * pm_sigma

# additional optimization step
# may be useful, may be not
# seqs = alignment.collect { |al| al[:from_seq] }
# alignment = get_sequence_alignment(seqs, pm)
# pm = PM.weighted_pcm(alignment)

save_bismark(pm, alignment, ARGV[1], motif_name, pm.infocod, threshold, pwm)
system("ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo.rb #{ARGV[1]} #{ARGV[1]}.png #{pm.words_count}")