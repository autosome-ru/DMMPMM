#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"
require "#{File.dirname(File.expand_path(__FILE__))}/pmento.rb"

report "flancalc.rb started, usage: <bismark_sequences> <starting_motif_length> <motif_length> <add_flank>"
start __FILE__
exit if ARGV.size < 4

bismark_sequences, start_motif_length, motif_length, add_flank = ARGV
start_motif_length = start_motif_length.to_i
motif_length = motif_length.to_i

checkerr("motif length < starting motif length") { motif_length < start_motif_length }

add_flank = add_flank.to_i

min_sequence_length = XPath.match(Bismark.new(bismark_sequences), path="//segment").collect { |e| e.attribute("length").value.to_i }.min
start_flank_length = (start_motif_length > min_sequence_length ? start_motif_length - min_sequence_length : 0) + add_flank
report "starting flank length was=#{start_flank_length}"
flank_length = start_flank_length + (motif_length - start_motif_length)

report "calculated flank length=#{flank_length}"
Rekeeper.keepp("FLANK_LENGTH", flank_length, "calculated flank length") 