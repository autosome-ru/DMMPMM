#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"

report "pmsim.rb started, usage <output_file_name> <background_ACGT>=default|0.25,0.25,0.25,0.25 <bismark_motif1>..<bismark_motifN>"
start __FILE__

exit(2) if ARGV.size < 4
out = File.new(ARGV.shift, "w")
background = ARGV.shift
background = background != "default" ? background.split(",").collect { |av| av.to_f } : [0.25, 0.25, 0.25, 0.25]
background = {'A' => background[0], 'C' => background[1], 'G' => background[2], 'T' => background[3]}

report "loading PWMs"
bismarks = ARGV.collect { |argv| Bismark.new(argv) }
names = ARGV.collect { |argv| File.name_wo_ext(argv) }
pwms = bismarks.collect { |bm| 
  checkerr("no threshold specified") { !bm.elements["//PWM"].attribute("threshold") }
  {:pm => PM.from_bismark(bm.elements["//PWM"]), :threshold => bm.elements["//PWM"].attribute("threshold").value.to_f} 
}

out.puts names.inject("") { |s, f_n| s << "\t#{f_n}" }

blacklist = []
result = {}
pwms.each_with_index { |pwm1h, i|
  report "processing #{names[i]}"
  pwm1 = pwm1h[:pm]
  
  simkoefs = ""
  
  pwms.each_with_index { |pwm2h, j|
    pwm2 = pwm2h[:pm]
    
    report "processing #{names[i]} vs #{names[j]} (#{j} of #{pwms.size})"
    if result[[i,j].sort]
      simkoefs << "\t#{result[[i,j].sort]}"
    elsif blacklist.include?(j)
      result[[i,j].sort] = "*"
      simkoefs << "\t*"
    else
      curmaxlen = pwm1.size + pwm2.size - 1
      p_a = Extlz.p_value(pwm1, pwm1h[:threshold], curmaxlen, true, background)
      unless p_a
        blacklist << i
        simkoefs = "\t*"*pwms.size
        break
      end
      p_b = Extlz.p_value(pwm2, pwm2h[:threshold], curmaxlen, true, background)
      unless p_b
        blacklist << j
        simkoefs << "\t*"
        next
      end
      
      p_ab = Extlz.p_value([pwm1, pwm2], [pwm1h[:threshold],pwm2h[:threshold]], curmaxlen, true, background)
      if p_ab
        simkoef = p_ab / Math.sqrt(p_a * p_b)
        result[[i,j].sort] = simkoef
        simkoefs << "\t#{simkoef}"
      else
        result[[i,j].sort] = "*"
        simkoefs << "\t*"
      end
    end
  }
  
  out.puts "#{names[i]}#{simkoefs}"
}

# some cleaning
Dir["*.prob"].each { |fn| File.delete(fn) }
Dir["*.pat"].each { |fn| File.delete(fn) }
