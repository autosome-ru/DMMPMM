#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"
require "#{File.dirname(File.expand_path(__FILE__))}/pmento.rb"
require "#{File.dirname(File.expand_path(__FILE__))}/bigfoot_llib.rb"

def get_flank(delta)
  delta > 0 ? delta : 0
end

report "bigfoot.rb started, usage: <bismark_output> <bismark_input> <motif_name> [<genome_release>] [<motif_length>=6] [<flank_length>=0] [<strict_flank>=no|yes] [<extended_mode>=no|yes] [<acgt_mode>=no|yes] [<refine_steps>=100]"
report "TODO: check PM usage against unknown letters in sequences"
report "WARNING: flank_length is discarded in case of local segments"
report "WARNING: refine_steps is used only in a slow engine optimizations"

start __FILE__
exit(2) if ARGV.size < 3

bismark_output, bismark_input, motif_name, genome_release, motif_length, flank_length, strict_flank, extended_mode, acgt_mode, refine_steps = ARGV

refine_steps = refine_steps ? refine_steps.to_i : 100
motif_length = motif_length ? motif_length.to_i : 6
flank_length = flank_length ? flank_length.to_i : 0
strict_flank = strict_flank && strict_flank != "false" && strict_flank != "no"
extended_mode = extended_mode && extended_mode != "false" && extended_mode != "no"
acgt_mode = acgt_mode && acgt_mode != "false" && acgt_mode != "no"

lengths = []
Bismark.new(ARGV[1]).elements.each("//segment") { |e| lengths << e.attribute("length").value.to_i }
min_sequence_length = lengths.min
flank_length = get_flank(motif_length - min_sequence_length) + flank_length unless strict_flank

report "using flank_length=#{flank_length}, minimum sequence length=#{min_sequence_length}"

best, result = nil, {}
  
bigfoot = Bigfoot.new(bismark_input, flank_length, genome_release, refine_steps, motif_length, extended_mode, acgt_mode, :float)
best = bigfoot.foot

checkerr("no motif found") { best == nil }

Rekeeper.keepp("POSITION_INFOCOD", best[:pm].infocod, "best discrete information content for motif #{motif_name} (bismark=#{bismark_output})")
Rekeeper.keepp("TOTAL_INFOCOD", best[:total_infocod], "best discrete information content for motif #{motif_name} (bismark=#{bismark_output})")
Rekeeper.keepp("MOTIF_LENGTH", best[:pm].size, "motif length used")
Rekeeper.keepp("FLANK_LENGTH", flank_length, "flank length used")
Rekeeper.keepp("BEST_PAIR", best[:pair], "words pair used for initial PCM construction")
Rekeeper.keepp("SEQUENCE_COUNT", lengths.size, "sequence set size")
Rekeeper.keepp("EXTENDED_MODE", extended_mode, "extended search mode")

report "best discrete information content found: #{best[:total_infocod]}"

save_bismark(best[:pm], best[:alignment], bismark_output, motif_name, best[:pm].infocod)
system("ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo.rb #{bismark_output} #{bismark_output}.png #{lengths.size}")
Rekeeper.keepr("MOTIF_LOGO", "#{bismark_output}.png", "resulting motif logo")
