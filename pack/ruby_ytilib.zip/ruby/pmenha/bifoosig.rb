#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"
require "#{File.dirname(File.expand_path(__FILE__))}/pmento.rb"
require "ftools"

report "bifoosig.rb started, usage: <bismark_output> <bismark_input_sequences> <motif_name> [<genome_release>] [<flank_length>=0] [<length_mode>=signature|variance|disabled] [<min_motif_length>=6] [<max_motif_length>=20] [<extended_mode>=no|yes]"
start __FILE__

def infocod_equal(segs_size, file_small, file_big)
  pm_small = PM.from_bismark(Bismark.new(file_small).elements["//PPM"])
  pm_big = PM.from_bismark(Bismark.new(file_big).elements["//PPM"])
  pm_small.words_count = segs_size
  pm_big.words_count = segs_size
  pm_small.infocod.inject(0) { |sum, icd| sum += icd } == pm_big.infocod.inject(0) { |sum, icd| sum += icd }
end

def inner_comp_sign(sign1, sign2)
  (0...sign1.size).each { |pos|
    return false if (sign1[pos] & sign2[pos]).empty?
  }
  return true
end

def comp_sign(sign_sm, sign_bg)
  sign_bg_rc = (0...sign_bg.size).collect { |pos| 
    sign_bg[pos].collect { |l| l.revcomp }
  }.reverse
  sign_templ1 = sign_bg_rc[0..-2]
  sign_templ2 = sign_bg_rc[1..-1]
  sign_templ3 = sign_bg[0..-2]
  sign_templ4 = sign_bg[1..-1]
  
  return inner_comp_sign(sign_sm, sign_templ1) || inner_comp_sign(sign_sm, sign_templ2) || inner_comp_sign(sign_sm, sign_templ3) || inner_comp_sign(sign_sm, sign_templ4)
  
end

def signature(pm)
  sign = []
  pm = pm.matrix
  (0...pm['A'].size).each { |position|
    best_letters = ['A','C','G','T'].select { |l| pm[l][position] > 0 }.sort { |b,a| pm[a][position] <=> pm[b][position] }[0,1]
    last_score = pm[best_letters.last][position]
    best_letters.concat(['A','C','G','T'].select { |l| pm[l][position] == last_score }).uniq!
    sign << best_letters
  }
  sign
end

Rekeeper.clear

exit(2) if ARGV.size < 3

program_path = File.dirname(File.expand_path(__FILE__))

bismark_output, bismark_input, motif_name, genome_release, flank_length, mode, minmole, maxmole, extended_mode = ARGV
genome_release = :llib unless genome_release
flank_length = flank_length ? flank_length.to_i : 0
minmole = minmole ? minmole.to_i : 6
maxmole = maxmole ? maxmole.to_i : 20
extended_mode = (extended_mode && extended_mode != "no" && extended_mode != "false") ? "true" : "false"

mode = {"variance" => :variance, "signature" => :signature, "disabled" => :disabled, "" => :disabled, nil => :disabled }[mode]
Rekeeper.keepp("LENGTH_MODE", mode.to_s, "motif length identification mode")

add_flank_length = flank_length
result_name = File.name_wo_ext(bismark_output)
size, not_found = minmole, true

segs_size = XPath.match(Bismark.new(bismark_input), path="//segment").size
Rekeeper.keepp("SEQUENCE_COUNT", segs_size, "total number of sequences in the set")
Rekeeper.keepp("EXTENDED_MODE", extended_mode, "extended search mode")

min_sequence_length = XPath.match(Bismark.new(bismark_input), path="//segment").collect { |e| e.attribute("length").value.to_i }.min

Rekeeper.keepp("MIN_SEQUENCE_LENGTH", min_sequence_length, "length of the shortest sequence in the set")

flank_length = ( (minmole - min_sequence_length) > 0 ? minmole - min_sequence_length : 0) + add_flank_length
report "using flank_length=#{flank_length}, minimum sequence length=#{min_sequence_length}"
Rekeeper.keepp("ADD_FLANK_LENGTH", add_flank_length, "additional flank length")
Rekeeper.keepp("START_FLANK_LENGTH", flank_length, "starting flank length used for the shortest motif")

report "using #{maxmole} as maximum adequate motif length"

report "proceeding with some cleaning"

File.delete("#{result_name}.xml") if File.exist?("#{result_name}.xml")
File.delete("#{result_name}.xml.png") if File.exist?("#{result_name}.xml.png")

flank_length -= 1
size -= 1
report "preparing motif of different sizes"
deltas, phases, infocods, position_infocods, flanks = [], [], [], [], []
while (size += 1) < maxmole+1 && (flank_length += 1)
  report "new flank length to be used: #{flank_length}"
  
  system("ruby #{program_path}/bigfoot.rb #{result_name}_#{size}.xml #{bismark_input} #{motif_name.cmd_line} #{genome_release} #{size} #{flank_length} yes #{extended_mode}") unless File.exist?("#{result_name}_#{size}.xml")
  
  reader = Rereader.new
  deltas << reader.get("bigfoot", "LEADER_DELTA")[:value]
  phases << reader.get("bigfoot", "LEADER_PHASE")[:value]
  infocods << reader.get("bigfoot", "TOTAL_INFOCOD")[:value]
  #pms = PM.from_bismark(Bismark.new("#{result_name}_#{size}.xml").elements["//PPM"])
  #pms.words_count = segs_size
  position_infocods << reader.get("bigfoot", "POSITION_INFOCOD")[:value] #pms.infocod
  flanks << flank_length
end

Rekeeper.keepp("MIN_MOTIF_LENGTH", minmole, "minimum motif length allowed")
Rekeeper.keepp("MAX_MOTIF_LENGTH", maxmole, "maximum motif length allowed")
Rekeeper.keepp("LEADER_DELTA", deltas, "delta for word-pair corresponding to matrix with the best final discrete information content for different motif lengths")
Rekeeper.keepp("LEADER_PHASE", phases, "<Footstep> search phase corresponding to matrix with the best final discrete information content for different motif lengths")
Rekeeper.keepp("TOTAL_INFOCOD", infocods, "best total discrete information content for different motif lengths")

if mode == :signature
  signatures = {}
  size = minmole
  size -= 1
  flank_length = ( (minmole - min_sequence_length) > 0 ? minmole - min_sequence_length : 0) + add_flank_length
  flank_length -= 1
  while not_found && (size += 1) < maxmole+1 && (flank_length += 1)
    report "new flank length to be used: #{flank_length}"
    
    system("ruby #{program_path}/bigfoot.rb #{result_name}_#{size}.xml #{bismark_input} #{motif_name.cmd_line} #{genome_release} #{size} #{flank_length} yes #{extended_mode}") unless File.exist?("#{result_name}_#{size}.xml")
    
    signatures[size] = signature( PM.from_bismark(Bismark.new("#{result_name}_#{size}.xml").elements["//PPM"]) )
    
    report "running stability check for motif length #{size}"
    
    not_found = signatures.size < 3 || infocod_equal(segs_size, "#{result_name}_#{size-1}.xml", "#{result_name}_#{size}.xml") || !(comp_sign(signatures[size-2], signatures[size-1]) && !comp_sign(signatures[size-1], signatures[size]))
  end
elsif mode == :variance
  not_found = false
  motifs = (minmole..maxmole).collect  { |size|
    { :motif_length => size, :icd_var => position_infocods[size-minmole].variance }
  }
  Rekeeper.keepp("INFOCOD_VARIANCE", motifs.collect { |m| m[:icd_var] } , "discrete information content variance over position for different motif lengths")
  motifs.sort! { |a,b| b[:icd_var] <=> a[:icd_var] }
  size = motifs.first[:motif_length] + 1# to save size-1
  flank_length = flanks[size-1-minmole] + 1#to save flank_length-1
  #else mode == :disabled
end

unless not_found
  Rekeeper.keepp("MOTIF_FOUND", true, "motif correctly identified")
  report "got correct motif of length #{size-1}"
  Rekeeper.keepp("MOTIF_LENGTH", size-1, "motif length found")
  Rekeeper.keepp("FLANK_LENGTH", flank_length-1, "sequence flank used for resulting motif construction") 
  
  File.copy("#{result_name}_#{size-1}.xml", "#{result_name}.xml")
  system("ruby #{Ytilib::PATH_RUBY}pmflogo/pmflogo.rb #{result_name}.xml #{result_name}.xml.png #{segs_size}")

  Rekeeper.keepr("MOTIF", "#{result_name}.xml", "resulting motif")
  Rekeeper.keepr("MOTIF_LOGO", "#{result_name}.xml.png", "logo for resulting motif")
else
  Rekeeper.keepp("MOTIF_FOUND", false, "no motif found till length #{maxmole}")
  report "no motif found till length #{maxmole}"
end