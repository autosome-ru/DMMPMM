#!/usr/bin/ruby
$: << "#{File.dirname(File.dirname(File.expand_path(__FILE__)))}/ytilib/"
require "ytilib.rb"
require "#{File.dirname(File.expand_path(__FILE__))}/pmento.rb"

report "icdhack.rb started, usage <sequence_file> <ppm_bismark_template>|<ppm_bismark1>..<ppm_bismarkN>"
start __FILE__
exit(2) if ARGV.size < 2

sequences = XPath.match(Bismark.new(ARGV.shift).root, "//sequence").collect { |e| e.get_text.to_s }

sequence_count = sequences.size
if ARGV.size > 1
  pms = ARGV.collect { |f_n| PM.from_bismark(Bismark.new(f_n).elements["//PPM"]) }
  names = ARGV.collect { |f_n| f_n }
elsif File.ext_wo_name(ARGV[0]) == "xml"
  pms = [PM.from_bismark(Bismark.new(ARGV[0]).elements["//PPM"])]
  names = [ARGV[0]]
else
  pms, names = [], []
  (6..17*17).each { |i|
    f_n = "#{ARGV[0]}_#{i}.xml"
    break unless (pms.empty? || File.exist?(f_n))
    next unless File.exist?(f_n)
    pms << PM.from_bismark(Bismark.new(f_n).elements["//PPM"])
    names << f_n
  }
end

def totalprobs(seqs)
  probsa = seqs.collect { |s| Randoom.calc_probs(s) }
  probs = ['A','C','G','T'].inject({"A" => 0, 'C' => 0, 'T' => 0, 'G' => 0}) { |sum, l| 
    probsa.each { |prob| sum[l] += prob[l] } 
    sum
  }
  ['A','C','G','T'].each { |l| probs[l] /= seqs.size  }
  Randoom.twostrand!(probs)
end

class PM
  def xi2_column(column, probs = Randoom::DEF_PROBS)
    #probs = {"A" => @matrix['A'][column] / @words_count, "C" => @matrix['C'][column] / @words_count, "G" => @matrix['G'][column] / @words_count, "T" => @matrix['T'][column] / @words_count}
    #Randoom.equalize!(probs)
    
    ['A','C','G','T'].inject(0) { |sum, l|
      sum += ( ( @matrix[l][column] - @words_count*probs[l] )**2 / (@words_count * probs[l]) )
      # (nu_l - n*p_l)**2 / (n*p_l)
    }
  end
  def xi2(probs = Randoom::DEF_PROBS)
    (0...@size).collect { |pos| xi2_column(pos, probs) }
  end
end

probs = totalprobs(sequences)
#p probs
#probs = Randoom::DMEL40_PROBS2
#probs = Randoom::DEF_PROBS

names.each_with_index { |name, i|
  pm = pms[i].get_pcm(sequences.size)
  #p pm.matrix['A'][12]
  #p pm.matrix['C'][12]
  #p pm.matrix['G'][12]
  #p pm.matrix['T'][12]
  xi2 = pm.xi2(probs)
  xi2b = xi2.collect { |x| x > 11.3 }
  leftb, rightb = xi2b.index(true), xi2b.rindex(true)
  totalgood = xi2.inject(0) { |sum, pe| sum += pe > 11.3 ? 1 : 0}
  lengthgood = rightb-leftb+1
  p "size=#{pm.size}, sumall=#{xi2.inject(0) {|sum, xi| sum += xi}}, sumgood=#{xi2.inject(0) {|sum, xi| sum += xi > 11.3 ? xi : 0}}, shorter=#{xi2[0] < 11.3 || xi2.last < 11.3}, totalgood=#{totalgood}, lengthgood=#{lengthgood}, #{totalgood.to_f/lengthgood}"
}

names.each_with_index { |name, i|
  pms[i].words_count = sequence_count
  icdt = pms[i].infocod.inject(0) { |sum, icd| sum += icd }
  icd = pms[i].infocod
  scores = []
  Bismark.new(name).elements.each("//word") { |word|
    scores << word.attribute("score").value.to_f
  }
  
  var_icd = icd.variance
  
  report "matrix #{name} has info.co.d=#{icdt}, info.co.d.variance=#{var_icd}"
}